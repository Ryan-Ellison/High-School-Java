
public class Test {

	public static void main(String[] args) {
		String start="abcde";
		String end="wxyz";
		int a = 1;
		System.out.println("The middle position is: " + findMiddlePos(start));
		System.out.println("The middle character is: " + findMiddleStr(start));
		System.out.println("Every second character is: " + everyOther(start));
		System.out.println("Halvsies is: " + halvsies(start,end));
		parts(start,a);
		System.out.println("The reverse of the string is: " + reverseStr(start));
		if (isPalindrome(start))
			System.out.println(start + " is a palindrome");
		else
			System.out.println(start + " is not a palindrome");
		if (evenOrOdd(start))
			System.out.println(start + " is even");
		else
			System.out.println(start + " is odd");
		

	}//end main
	
	public static double findMiddlePos(String String){
		double a = 0.0;
		a=String.length()/2.0-0.5;
		return a;
	}//end findMiddlePos
	
	public static String findMiddleStr(String a) {
		if (a.length()%2==1)
			return Character.toString(a.charAt((int)findMiddlePos(a)));
		else {
			String z =  Character.toString(a.charAt((int)findMiddlePos(a))) + Character.toString(a.charAt((int)findMiddlePos(a+1)));
			return z;
		}//end else statement
	}//end findMiddleStr
	
	public static String everyOther (String a) {
		String z = "";
		for (int i=0;i<a.length();i++) {
			if (i%2==0)
				z = z + a.charAt(i);
		}//end for loop
		return z;
	}//end everyOther
	
	public static String halvsies(String a, String b) {
		String x = a.substring(0, a.length()/2);
		String z= b.substring(b.length()/2, b.length());
		return x + z;
	}//end halvsies
	
	public static void parts(String a, int b) {
		int z=0;
			for (int d=0;d<b;d++) {
				System.out.println();
				for (int i =0;i<a.length()/b;i++) {
					System.out.print(a.charAt(z));
					z++;
				}//end print loop
			}//end total
			System.out.println(a.substring(z, a.length()));
	}//end parts
	
	public static String reverseStr(String a) {
		String z="";
		for(int i=(a.length()-1);i>=0;i--) {
			z += a.charAt(i);
		}
		return z;
	}//end reverseStr
	
	public static boolean isPalindrome(String a) {
		if (a.equals(reverseStr(a)))
			return true;
		else
			return false;
	}//end isPalindrome
	
	public static boolean evenOrOdd(String a) {
		int z=0;
		for (int i=0;i< a.length();i++) {
			z+=((int)a.charAt(i));
		}
		if (z%2==0)
			return true;
		else
			return false;
	}
}
