
public class ArrayStuff {

	public static void main(String[] args) {
		int[] arr=new int[5];
		//arr[0]=12;
		//System.out.println(arr[0]);
		//int random = (int)(Math.random()*19)-11;
		//System.out.println(random);
		printArray(arr);
		assignRand(arr); 
		printArray(arr);
		
	}//end main
	
	public static void assignRand(int[] x) {
		for (int i=0;i<x.length;i++) {
			x[i]=(int)(Math.random()*11)-5;
		}//end for
	}//end assignRand
	
	public static void printArray(int[] x) {
		for (int i=0;i<x.length;i++) {
			System.out.print(x[i] + " ");
		}//end for
		System.out.println();
	}//end printArray
}//end class
