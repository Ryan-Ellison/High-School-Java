import java.util.Scanner;

public class LockerProblem{
	/*Answers:
	 * 
	 * Which lockers will be left open?
	 * 1,4,9,16,25,36,49,64,81,100
	 * 
	 * Explain how you determined this
	 * the numbers are perfect squares, which means they are touched an odd number of times
	 * 
	 * What do you notice about these particular lockers?
	 * They're perfect squares
	 * 
	 * Why are these specific lockers open?
	 * They have an odd number of factors because they are perfect squares.
	 * The other lockers have an even number of factors because you need to multiply all factors by a different unique number.
	 * 
	 * How many lockers, and which ones, were touched exactly twice?
	 * 25-2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,89,97
	 * They are the prime numbers
	 * 
	 * Which students touched both lockers 36 & 48? How do you know?
	 * 1,2,3,4,6&12, they are the common factors between 36 and 48
	 * 
	 * Which lockers were switched the most? how do you know?
	 * 60,72,84,90 & 96, they have the most factors
	 * 
	 * 
	 * EXTENDED PROBLEMS
	 * 
	 * How does the prime factorization and the number of factors a number has compare?
	 * You add 1 to each exponent in the prime factorization, then multiply all the exponents in prime factors.
	 * 
	 * Use 24's prime factorization and #1's answer to see the factors of 24
	 * 2^3*3^1, 4*2=8 factors
	 * 2^0*3^0,2^1*3^0,2^2*3^0,2^3*3^0
	 * 2^0*3^1,2^1*3^1,2^2*3^1,2^3*3^1
	 * 1,2,4,8
	 * 3,6,12,24
	 * 
	 * How many factors does the number 432 have?
	 * 432 has 20 factors
	 * 
	 * How can the prime factorization be used to find the factors?
	 * The same way i did Question #2
	 * 
	 * List the factors of 432
	 * 1,2,3,4,6,8,9,12,16,18,24,27,36,48,54,72,108,144,216,432 
	 * 
	 * How many times would locker 432 be touched? which people would touch it?
	 * 20
	 * 1,2,3,4,6,8,9,12,16,18,24,27,36,48,54,72,108,144,216,432
	 * 
	 */
	public static void main(String[] args) {
		String[] lockers=new String[100];
		lockers=fillLockers();
		for(int i=0;i<lockers.length;i++) {
			System.out.print(lockers[i]+" ");
		}
		System.out.println();
		System.out.println(factors());
		Scanner in=new Scanner(System.in);
		int factoredNumber=in.nextInt();
		in.close();
		System.out.println(whatFactors(factoredNumber));
	}
	
	public static String[] fillLockers() {
		String[] temp=new String[100];
		for(int i=0;i<100;i++) {
			temp[i]="closed";
		}
		int z=0;
		int k=0;
		for(int i=1;i<100;i++) {
			z=1;
			k=0;
			while(k==0) {
				if (temp[(i*z)-1]=="closed")
					temp[(i*z)-1]="open";
				else if(temp[(i*z)-1]=="open")
					temp[(i*z)-1]="closed";
				z++;
				if((i*z)>99||z>99) {
					k=1;
				}
			}
		}
		return temp;
	}
	
	public static String factors() {
		String temp="";
		int factors=0;
		int intTemp=0;
		for(int i=1;i<101;i++) {
			factors=0;
			for(int k=1;k<51;k++) {
				if(i%k==0)
					factors++;
			}
			if(factors>intTemp) {
				intTemp=factors;
				temp=Integer.toString(i);
			}
			else if(factors==intTemp) {
				temp+=(" " + i);
			}
		}
		return temp;
	}

	public static String whatFactors(int number) {
		String temp="";
		int tempInt=0;
		for(int i=1;i<=number;i++) {
			if(number%i==0) {
				temp=temp+i;
				temp=temp+" ";
				tempInt++;
			}
		}
		temp += "\n" + tempInt;
		return temp;
	}
	
}