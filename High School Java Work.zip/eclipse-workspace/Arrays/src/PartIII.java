import java.util.Scanner;

public class PartIII {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int numbers=in.nextInt();
		in.close();
		System.out.println(intLength(numbers));
		int[] array;
		array=fillArray(numbers);
		ArrProject.printArray(array);
		for(int i=0;i<array.length;i++) {
			System.out.print(array[i]+" ");
		}
	}
	
	public static int intLength(int number) {
		int temp=0;
		int i=0;
		while(i!=1) {
			if (number/Math.pow(10,temp)>=10)
				temp++;
			else
				i++;
		}
		return temp+1;
	}
	
	public static int[] fillArray(int number) {
		int temp=0;
		int[] array=new int[intLength(number)];
		for(int i=0;i<array.length;i++) {
			temp=number;
			temp=(int)(number/(Math.pow(10, array.length-i-1)));
			if (i!=0)
				temp=temp%((((int)(temp/10))*10));
			array[i]=temp;
		}
		return array;
	}

}
