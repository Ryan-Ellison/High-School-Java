import java.util.Scanner;

public class MineSweeper {
	
	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		System.out.println("How large do you want your board?");
		int dim=in.nextInt();//size of the array
		int[] bombs=new int[(int)(dim*1.5)];//number of bombs
		fillArray(bombs,dim*dim);
		int[][] infoBoard=new int[dim][dim];
		fillBoard(infoBoard,bombs);
		finishBoard(infoBoard);
		String[][] displayBoard=new String[dim][dim];
		fillDisplay(displayBoard);
		playGame(infoBoard,displayBoard);
		in.close();
	}
	
	/**
	 * Pre:
	 * @param array: a 2D int array
	 * @param numbers: the total number of elements in the minesweeper playing board
	 * Post:
	 * the 2D Array is filled with unique numbers from 0-(numbers-1)
	 */
	
	public static void fillArray(int[] array,int numbers) {
		for(int i=0;i<array.length;i++) {
			array[i]=(int)(Math.random()*numbers);
			for(int j=0;j<i;j++) {
				if(array[i]==array[j]) 
					i--;//if the number isn't unique, change previous numbers
			}
		}
	}
	
	/**
	 * Pre:
	 * @param array: a 2D int array
	 * Post:
	 * Prints the 2d Array with a space between each element
	 */
	
	public static void printArray(int[] array){
		for(int i=0;i<array.length;i++){
			System.out.print(array[i] + " ");
		}
		System.out.println();
		System.out.println();
	}

	/**
	 * Pre:
	 * @param board:a 2d int array representing the game board
	 * @param pos:an int array representing the position of each bomb
	 * Post:
	 * the board is filled with bombs at each position represented by pos array
	 */
	
	public static void fillBoard(int[][] board,int[] pos){
		for(int i=0;i<pos.length;i++){
			if(pos[i]%board.length>0)
				board[pos[i]/board.length][pos[i]%board.length-1]=-1;
			else
				board[(int)(pos[i]/board.length-0.1)][board.length-1]=-1;
		}
	}
	
	/**
	 * Pre:
	 * @param array:A 2D int array
	 * Post:
	 * Prints the array like a grid, space between each element
	 */
	
	public static void print2DArray(int[][] array){
		for(int i=0;i<array.length;i++){
			for(int j=0;j<array[0].length;j++){
				System.out.print(array[i][j]+" ");
			}
			System.out.println();
		}
		System.out.println();
	}

	/**
	 * Pre:
	 * @param board: a 2D board with -1 as a few elements
	 * Post:
	 * Each element that wasn't a -1 now equals the number of -1s touching the element
	 */
	
	public static void finishBoard(int[][] board){
		for(int i=0;i<board.length;i++){
			for(int j=0;j<board[0].length;j++){
				if(board[i][j]==-1){
					if(i+1<board.length&&j+1<board.length&&board[i+1][j+1]!=-1)
						board[i+1][j+1]+=1;
					if(i+1<board.length&&j-1>=0&&board[i+1][j-1]!=-1)
						board[i+1][j-1]+=1;
					if(i+1<board.length&&board[i+1][j]!=-1)
						board[i+1][j]+=1;
					if(i-1>=0&&j+1<board.length&&board[i-1][j+1]!=-1)
						board[i-1][j+1]+=1;
					if(i-1>=0&&j-1>=0&&board[i-1][j-1]!=-1)
						board[i-1][j-1]+=1;
					if(i-1>=0&&board[i-1][j]!=-1)
						board[i-1][j]+=1;
					if(j+1<board.length&&board[i][j+1]!=-1)
						board[i][j+1]+=1;
					if(j-1>=0&&board[i][j-1]!=-1)
						board[i][j-1]+=1;
					}
					
				}
			}
		}

	/**
	 * Pre:
	 * @param display:A 2D string array 
	 * Post:
	 * The array is filled with asterisks as every element
	 */
	
	public static void fillDisplay(String[][] display){
		for(int i=0;i<display.length;i++){
			for(int j=0;j<display.length;j++){
				display[i][j]="*";
			}
		}
	}
	
	/**
	 * Pre:
	 * @param array:A 2D String array
	 * Post:
	 * Prints the array like a grid, space between each element
	 */
	
	public static void print2DStringArray(String[][] array){
		for(int i=0;i<array.length;i++){
			for(int j=0;j<array[0].length;j++){
				System.out.print(array[i][j]+" ");
			}
			System.out.println();
		}
		System.out.println();
	}

/**
 	 * Pre:	
 * @param infoBoard: a board containing each bomb location and the numbers
 * @param displayBoard: a blank board that is shown to the player
 * Post:
 * Runs the game until completion or loss
 */
	
	public static void playGame(int[][] infoBoard,String[][] displayBoard) {
		int bombHit=0;
		int row=0;
		int column=0;
		int alikePos=0;
		int markBomb=0;
		Scanner in=new Scanner(System.in);
		while(bombHit==0&&alikePos<(displayBoard.length*displayBoard[0].length)) {
			print2DStringArray(displayBoard);
			System.out.println("Enter a row and a column");
			row=in.nextInt();
			column=in.nextInt();
			if(row==0&&column==0) {
				System.out.println("Would you like to mark a bomb or a safe spot?");
				System.out.println("Press 1 to mark a safe spot");
				System.out.println("Press 2 to mark a bomb");
				markBomb=in.nextInt();
				if(markBomb==1) {
					if(infoBoard[row][column]!=-1) 
						displayBoard[row][column]=Integer.toString(infoBoard[row][column]);
					else {
						bombHit=1;
						System.out.println("You hit a bomb!!!!!");
					}
				}
				if(markBomb==2) {
					displayBoard[row][column]="X";
				}
			}
			else if(row>=0&&column>=0) {
				if(infoBoard[row][column]!=-1)
					displayBoard[row][column]=Integer.toString(infoBoard[row][column]);
				else {
					bombHit=1;
					System.out.println("You hit a bomb!!!!!");
				}
			}
			else if(row<=0&&column<=0)
				displayBoard[row*-1][column*-1]="X";
			alikePos=gameOver(infoBoard,displayBoard);
		}
		if(alikePos>=(displayBoard.length*displayBoard[0].length))
			System.out.println("You won!!!!!!!!!!!");
		in.close();
	}
	
	/**
	 * Pre:
	 * @param infoBoard: the board that holds all of the original values
	 * @param gameBoard: the board that is edited as the game plays
	 * Post:
	 * @return the number of matches between infoboard and gameboard
	 */
	
	public static int gameOver(int[][] infoBoard,String[][] gameBoard) {
		int temp=0;
		for(int i=0;i<infoBoard.length;i++) {
			for(int j=0;j<infoBoard[0].length;j++) {
				if((gameBoard[i][j].equals(Integer.toString(infoBoard[i][j])))||(gameBoard[i][j].equals("X")&&infoBoard[i][j]==-1))//If the spots are equal or the two spots are an X and -1
					temp++;
			}
		}
		return temp;
	}

}
