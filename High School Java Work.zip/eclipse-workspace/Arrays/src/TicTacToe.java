import java.util.Scanner;

public class TicTacToe {

	public static void main(String[] args) {
		String[][] board=new String[5][5];
		fillBoard(board);
		playGame(board);
	}
	
	
	/**
	 * Pre:
	 * @param board: a 2D 5x5 string array representing the board
	 * Post:
	 * The board represents a tic tac toe board
	 */
	
	public static void fillBoard(String[][] board) {
		for(int i=0;i<board.length;i++) {
			for(int j=0;j<board[0].length;j++) {
				if(i%2==0&&j%2==1) {
					board[i][j]="|";
				}
				else if(i%2==1&&j%2==0) {
					board[i][j]="_";
				}
				else
					board[i][j]="";
			}
		}
	}
	
	
	/**
	 * Pre:
	 * @param board: a 2d string array representing the player board
	 * @param row: the row the player entered
	 * @param column: the column the player entered
	 * @param player: what player is currently going
	 * Post:
	 * Changes the position of the board that would correspond to the 
	 * entered positions to whoever is playing
	 */
	
	public static void enterPosition(String[][] board,int row,int column,String player) {
		if(row==1&&column==1) {
			board[0][0]=player;
		}
		if(row==1&&column==2) {
			board[0][2]=(player);
		}
		if(row==2&&column==1) {
			board[2][0]=(player);
		}
		if(row==1&&column==3) {
			board[0][4]=(player);
		}
		if(row==3&&column==1) {
			board[4][0]=(player);
		}
		if(row==2&&column==2) {
			board[2][2]=(player);
		}
		if(row==3&&column==2) {
			board[4][2]=(player);
		}
		if(row==2&&column==3) {
			board[2][4]=(player);
		}
		if(row==3&&column==3) {
			board[4][4]=(player);
		}
	}
	
	/**
	 * Pre:
	 * @param board: A 2D string array representing the playing board
	 * Post:
	 * @returns who won the game if there is a victor present, otherwise says no one one
	 */
	
	public static int won(String[][] board) {
		int temp=0;
		if(board[0][0]=="X") {
			if(board[0][0]==board[0][2]&&board[0][0]==board[0][4]) {
				temp=1;
			}
			if(board[0][0]==board[2][0]&&board[0][0]==board[4][0]) {
				temp=1;
			}
			if(board[0][0]==board[2][2]&&board[0][0]==board[4][4]) {
				temp=1;
			}
		}
		if(board[4][4]=="X") {
			if(board[4][4]==board[4][2]&&board[4][4]==board[4][0]) {
				temp=1;
			}
			if(board[4][4]==board[2][4]&&board[4][4]==board[0][4]) {
				temp=1;
			}
		}
		if(board[2][2]=="X") {
			if(board[2][2]==board[2][0]&&board[2][2]==board[2][4]) {
				temp=1;
			}
			if(board[2][2]==board[0][2]&&board[2][2]==board[4][2]) {
				temp=1;
			}
		}
		if(board[0][0]=="O") {
			if(board[0][0]==board[0][2]&&board[0][0]==board[0][4]) {
				temp=2;
			}
			if(board[0][0]==board[2][0]&&board[0][0]==board[4][0]) {
				temp=2;
			}
			if(board[0][0]==board[2][2]&&board[0][0]==board[4][4]) {
				temp=2;
			}
		}
		if(board[4][4]=="O") {
			if(board[4][4]==board[4][2]&&board[4][4]==board[4][0]) {
				temp=2;
			}
			if(board[4][4]==board[2][4]&&board[4][4]==board[0][4]) {
				temp=2;
			}
		}
		if(board[2][2]=="O") {
			if(board[2][2]==board[2][0]&&board[2][2]==board[2][4]) {
				temp=2;
			}
			if(board[2][2]==board[0][2]&&board[2][2]==board[4][2]) {
				temp=2;
			}
		}
		return temp;
	}
	
	/**
	 * Pre:
	 * @param board: a 2D string array representing the playing board
	 * @param player: an int representing who's turn it currently is
	 * @param in: a scanner to fill in prompts
	 * Post:
	 * Gathers the row and column that were entered
	 */
	
	public static void prompts(String[][] board, int player,Scanner in) {
		player++;
		System.out.println("Player "+player+" input a position");
		int row=in.nextInt();
		int column=in.nextInt();
		if(player==1)
			enterPosition(board,row,column,"X");
		else
			enterPosition(board,row,column,"O");
		MineSweeper.print2DStringArray(board);
	}
	
	/**
	 * Pre: 
	 * @param board: a 2d string array representing the playing board
	 * Post:
	 * Runs the entirety of the game calling various methods ending 
	 * when the players have decided they are done
	 */
	
	
	public static void playGame(String[][] board) {
		Scanner in=new Scanner(System.in);
		int plays=0;
		int gameOver=0;
		String playing="y";
		int player1Score=0;
		int player2Score=0;
		int i=0;
		while(playing.equals("y")) {
			fillBoard(board);
			MineSweeper.print2DStringArray(board);
			i=0;
			gameOver=0;
			plays=0;
			while(plays<9&&gameOver==0) {
				prompts(board,i%2,in);
				gameOver=won(board);
				i++;
				plays++;
			}
			if (gameOver==1) {
				System.out.println("Player one won!");
				player1Score++;
			}
			else if (gameOver==2) {
				System.out.println("Player two won!");
				player2Score++;
			}
			else if (gameOver==0)
				System.out.println("No one won!");
			System.out.println("Player one has " + player1Score + " points");
			System.out.println("Player two has " + player2Score + " points");
			System.out.println("Would you like to play again? y/n");
			in.nextLine();
			playing=in.nextLine();
			}
		}
}
