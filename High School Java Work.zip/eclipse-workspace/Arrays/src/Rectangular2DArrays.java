import java.util.Scanner;
/**
 * diagonals do not work unfortunately
 *
 */
public class Rectangular2DArrays {

	public static void main(String[] args) {
		int rows=3;
		int columns=4;
		int rows2=4;
		int columns2=3;
		int[][] array=new int[rows][columns];
		int[][] matrix2=new int[rows2][columns2];
		ArraysBut2DProject.fillArray(array);
		ArrayNotes2D.rowMajorOrder(array);
		ArraysBut2DProject.fillArray(matrix2);
		int sum=ArraysBut2DProject.sumAll(array);
		System.out.println("The sum of each element in the array is: "+sum);
		int largestRow=ArraysBut2DProject.findLargestRow(array);
		System.out.println("The largest row is row#: "+largestRow);
		int largestColumn=ArraysBut2DProject.findLargestColumn(array);
		System.out.println("The largest column is column#: "+largestColumn);
		int sum2=ArraysBut2DProject.efficientSumAll(array);
		System.out.println("The sum of each element in the array is: "+sum2);
		Scanner in=new Scanner(System.in);
		System.out.println("Choose a position in the array(0 - "+array.length*array[0].length+")");
		int position=in.nextInt();
		int positionNumber=ArraysBut2DProject.findPos(array,position);
		System.out.println("The position you chose contains this #: "+positionNumber);
		int[][] array2=new int[rows][columns];
		ArraysBut2DProject.makeCopy(array,array2);;
		System.out.println("Enter a row number");
		int row=in.nextInt();
		System.out.println("Enter a column number");
		int column=in.nextInt();
		System.out.println("Dominate Axis");
		ArraysBut2DProject.dominateAxis(array2, row, column);
		ArrayNotes2D.rowMajorOrder(array2);
		System.out.println();
		int[][] array3=new int[rows][columns];
		System.out.println("Dominate Diagonal");
		ArraysBut2DProject.makeCopy(array,array3);
		ArraysBut2DProject.dominateDiag(array3, row, column);
		ArrayNotes2D.rowMajorOrder(array3);
		System.out.println();
		in.close();
		int[][] transposedArray=new int[columns][rows];
		transpose(array,transposedArray);
		System.out.println("A copy of the original array");
		ArrayNotes2D.rowMajorOrder(array);
		System.out.println("The original array transposed");
		ArrayNotes2D.rowMajorOrder(transposedArray);
		System.out.println("The array to multiply with the original");
		ArrayNotes2D.rowMajorOrder(matrix2);
		int[][] multiplyAnswer=new int[rows][columns2];
		System.out.println("An array times the previously printed array");
		multiplyArray(array,matrix2,multiplyAnswer);
		ArrayNotes2D.rowMajorOrder(multiplyAnswer);
		int[][] arrayWithTransposed=new int[rows][rows];
		int[][] transposedWithArray=new int[columns][columns];
		System.out.println("The original array");
		ArrayNotes2D.rowMajorOrder(array);
		System.out.println("The transposed array");
		ArrayNotes2D.rowMajorOrder(transposedArray);
		multiplyArray(array,transposedArray,arrayWithTransposed);
		System.out.println("The original array times its transpose");
		ArrayNotes2D.rowMajorOrder(arrayWithTransposed);
		multiplyArray(transposedArray,array,transposedWithArray);
		System.out.println("The transposed array times its original");
		ArrayNotes2D.rowMajorOrder(transposedWithArray);
	}
	
	/**
	 * Pre: Two 2D int arrays, with opposite dimension lengths
	 * @param array
	 * @param transposed
	 * Post:
	 * The second 2D array is a replica of the 1st array but the rows become columns and vice versa
	 */
	
		public static void transpose(int[][] array,int[][] transposed) {
			for(int i=0;i<array.length;i++) {
				for(int j=0;j<array[0].length;j++) {
					transposed[j][i]=array[i][j];
				}
			}
		}

		/**
		 * Pre: 2 filled 2D int arrays, #rows of array1=#columns of array2.
		 * A blank 2D int array with dimensions[rows of array#1][columns of array#2]
		 * @param array
		 * @param array2
		 * @param multiplyAnswer
		 * Post:
		 * multiplyAnswer is array*array2 multiplied like matrices
		 */
		
		public static void multiplyArray(int[][] array,int [][]array2,int[][] multiplyAnswer) {
			int temp=0;
			if(array.length==array2[0].length) {
				for(int i=0;i<multiplyAnswer.length;i++) {
					for(int j=0;j<multiplyAnswer[0].length;j++){
						temp=0;
						for(int a=0;a<array[0].length;a++) {
							temp+=(array[i][a]*array2[a][j]);
						}//end third for loop
						multiplyAnswer[i][j]=temp;
					}//end second for loop
				}//end first for loop
			}//end if
			else {
				System.out.println("These arrays can't be multipled with eachother");
			}
			System.out.println();
		}
}


