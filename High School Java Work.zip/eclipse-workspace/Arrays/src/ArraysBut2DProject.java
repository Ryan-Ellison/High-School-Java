import java.util.Scanner;

public class ArraysBut2DProject {

	public static void main(String[] args) {
		int lengths=3;
		int[][] array=new int[lengths][lengths];
		fillArray(array);
		ArrayNotes2D.rowMajorOrder(array);
		int sum=sumAll(array);
		System.out.println("The sum of each element in the array is: "+sum);
		int largestRow=findLargestRow(array);
		System.out.println("The largest row is row#: "+largestRow);
		int largestColumn=findLargestColumn(array);
		System.out.println("The largest column is column#: "+largestColumn);
		int largestDiag=findLargestDiag(array);
		if(largestDiag!=0)
			System.out.println("The slope of the largest diagnol is: "+largestDiag);
		else
			System.out.println("The two diagnols are equal");
		int sum2=efficientSumAll(array);
		System.out.println("The sum of each element in the array is: "+sum2);
		Scanner in=new Scanner(System.in);
		System.out.println("Choose a position in the array(0 - "+array.length*array[0].length+" )");
		int position=in.nextInt();
		int positionNumber=findPos(array,position);
		System.out.println("The position you chose contains this #: "+positionNumber);
		int[][] array2=new int[lengths][lengths];
		makeCopy(array,array2);;
		System.out.println("Enter a row number");
		int row=in.nextInt();
		System.out.println("Enter a column number");
		int column=in.nextInt();
		dominateAxis(array2, row, column);
		ArrayNotes2D.rowMajorOrder(array2);
		System.out.println();
		int[][] array3=new int[lengths][lengths];
		makeCopy(array,array3);
		dominateDiag(array3, row, column);
		ArrayNotes2D.rowMajorOrder(array3);
		in.close();

	}
	
	/**
	 * Pre:A 2d integer array
	 * @param array
	 * Post:
	 * changes array to be filled with random integers 0-9, inclusive
	 */
	
	public static void fillArray(int[][] array) {
		for(int i=0;i<array.length;i++) {
			for(int j=0;j<array[0].length;j++) {
				array[i][j]=(int)(Math.random()*10);
			}
		}
	}

	/**
	 * Pre:A 2d integer array
	 * @param array
	 * @return
	 * the sum of every element inside the array
	 */
	
	public static int sumAll(int[][] array) {
		int temp=0;
		for(int i=0;i<array.length;i++) {
			for(int j=0;j<array[0].length;j++) {
				temp+=array[i][j];
			}
		}
		return temp;
	}
	
	/**
	 * Pre:a 2D integer array
	 * @param array
	 * @return
	 * The row number of the array with the largest sum, starting at 0
	 */
	
	public static int findLargestRow(int[][] array) {
		int row=0;
		int sumRow=0;
		int temp=0;
		for(int i=0;i<array.length;i++) {
			sumRow=rowSum(array, i);
			if (sumRow>temp) {
				temp=sumRow;
				row=i;
			}
		}
		return row;
	}

	/**
	 * Pre:A 2D array, and an integer >0 and < th
	 * @param array
	 * @param i
	 * @return
	 * returns the sum of the row
	 */
	
	public static int rowSum(int[][] array,int i) {
		int temp=0;
		for(int j=0;j<array[0].length;j++) {
			temp+=array[i][j];
		}
		return temp;
	}
	
	/**
	 * Pre:A 2D array
	 * @param array
	 * @return
	 * the column with the largest sum
	 */
	
	public static int findLargestColumn(int[][] array) {
		int col=0;
		int sumCol=0;
		int temp=0;
		for(int i=0;i<array.length;i++) {
			sumCol=colSum(array,i);
			if (sumCol>temp) {
				temp=sumCol;
				col=i;
			}
		}
		return col;
	}
	
	/**
	 * Pre:A 2D int array, and an int >0 and < the array[0] length
	 * @param array
	 * @param i
	 * @return
	 * the sum of the column
	 */
	
	public static int colSum(int[][] array, int i) {
		int temp=0;
		for(int j=0;j<array.length;j++) {
			temp+=array[j][i];
		}
		return temp;
	}
	
	/**
	 * Pre:A 2d int Array
	 * @param array
	 * @return
	 * the slope of the diagonal with the largest sum
	 * if both diagonals are equal, then it returns 0
	 */
	
	public static int findLargestDiag(int[][] array) {
		if(diagSum(array,1)>diagSum(array,-1))
			return -1;
		else if (diagSum(array,1)==diagSum(array,-1))
			return 0;
		else
			return 1;
	}
	
	/**
	 * Pre:A 2D int array, and a number 1 or -1 indicating the slope
	 * @param array
	 * @param slope
	 * @return
	 * returns the sum of the diagonal
	 */
	
	public static int diagSum(int[][] array, int slope) {
		int temp=0;
		if (slope==1) {
			for(int i=0;i<array.length;i++) {
				temp+=array[i][i];
			}
		}
		if (slope==-1) {
			for(int i=array.length-1;i>=0;i--) {
				temp+=array[array.length-i-1][i];
			}
		}
		return temp;
	}

	/**
	 * Pre:A 2d int array
	 * @param array
	 * @return
	 * The sum of each element in the array, but in a more efficient array
	 */

	public static int efficientSumAll(int[][] array) {
		int sum=0;
		for(int i=0;i<array.length;i++) {
			sum+=rowSum(array,i);
		}
		return sum;
	}
	
	/**
	 * Pre:A 2D int array, and a number (1-total number of elements in the array), inclusive
	 * @param array
	 * @param pos
	 * @return
	 * returns the element inside the position that was entered
	 * Goes from left to right, up to down
	 */
	
	public static int findPos(int[][] array, int pos) {
		int posNumber=0;
		if(pos%array.length>0)
			posNumber=array[pos/array.length][pos%array.length-1];
		else
			posNumber=array[(int)(pos/array.length-0.1)][array.length-1];
		return posNumber;
	}

	/**
	 * Pre:two 2D int arrays
	 * @param array
	 * @param array2
	 * Creates a copy of the 1st array in the 2nd array
	 */
	
	public static void makeCopy(int[][] array,int [][] array2) {
		for(int i=0;i<array.length;i++) {
			for(int j=0;j<array.length;j++) {
				array2[i][j]=array[i][j];
			}
		}
	}

	/**
	 * Pre:A 2D int array, a row number, and a column number(within the arrays limits)
	 * @param array
	 * @param row
	 * @param column
	 * Post:
	 * Changes array2 so that every element on the column and row inputted is equal to the int at the intersection
	 */
	
	public static void dominateAxis(int[][] array, int row, int column) {
		int temp=0;
		temp=array[row][column];
		for(int i=0;i<array.length;i++) {
			array[i][column]=temp;
		}
		for(int i=0;i<array[0].length;i++) {
			array[row][i]=temp;
		}
	}
	
	/**
	 * Pre: A 2D int array, a row number, and a column number (within the limits of the array)
	 * @param array
	 * @param row
	 * @param column
	 * Post:
	 * Changes array so that the diagonals of the selected position are all made into the said position
	 */
	
	public static void dominateDiag(int[][] array, int row, int column) {
		int temp=array[row][column];
		for(int i=0;i<array.length;i++) {
			for(int j=0;j<array[0].length;j++) {
				if(row-i>=0&&column-i>=0) 
					array[row-i][column-i]=temp;
				if(row-i>=0&&column+i<array[0].length)
					array[row-i][column+i]=temp;
				if(row+i<array.length&&column-i>=0)
					array[row+i][column-i]=temp;
				if(row+i<array.length&&column+i<array[0].length)
					array[row+i][column+i]=temp;
			}
		}
	}
}