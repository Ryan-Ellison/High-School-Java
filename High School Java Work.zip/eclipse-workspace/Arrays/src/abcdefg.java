
public class abcdefg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][][] array=new int[2][2][2];
		fill3DArray(array);
		print3DArray(array);
	}
	
	public static void fill3DArray(int[][][] array) {
		for(int i=0;i<array.length;i++) {
			for(int j=0;j<array.length;j++) {
				for(int k=0;k<array.length;k++) {
					array[i][j][k]=(int)(Math.random()*11);
				}
			}
		}
	}
	
	public static void print3DArray(int[][][] array) {
		for(int i=0;i<array.length;i++) {
			for(int j=0;j<array.length;j++) {
				for(int k=0;k<array.length;k++) {
					System.out.print(array[i][j][k]);
					System.out.print("  ");
				}
				System.out.println();
			}
		}
	}

}
