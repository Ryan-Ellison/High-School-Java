import java.util.Scanner;

public class ArrProject {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("How big is your array? ");
		int length=in.nextInt();
		System.out.println("What is the largest number your array can contain? ");
		int maximumNumber=in.nextInt();
		System.out.println("What is the smallest number your array can contain? ");
		int minimumNumber=in.nextInt();
		System.out.println("What number do you want to divide your array by? ");
		int divideNumber=in.nextInt();
		in.close();
		int[] intArray = randomNumbers(length,maximumNumber,minimumNumber);
		int sum=sumArray(intArray);
		int minimum=findMinimum(intArray);
		int maximum=findMaximum(intArray);
		double average=findAverage(intArray);
		boolean repeated=isRepeated(intArray);
		int[] copy=new int[intArray.length];
		copy=makeCopy(intArray);
		printArray(intArray);
		System.out.println("The sum of the array is: " + sum);
		System.out.println("The smallest number of the array is: " + minimum);
		System.out.println("The largest number of this array is: " + maximum);
		System.out.println("The average of this arrays is: " + average);
		System.out.println("There are numbers repeated. T/F " + repeated);
		System.out.print("Odds or Evens: ");
		printArray(oddOrEvens(intArray));
		System.out.print("The array is/isn't divisible by " + divideNumber + ": ");
		printArray(isDivisible(intArray,divideNumber));
		System.out.print("A copy of the array: ");
		printArray(copy);
		System.out.print("The array in reverse: ");
		printArray(makeReverse(intArray));
	}//end main
	

	/**
	 * Pre: An int stating the length of the array
	 * An int stating how large the highest number of the array can be
	 * An int stating how small the lowest number of array can be
	 * 
	 * Post:
	 * @return the array with random integers 1-100
	*/
	
	public static int[] randomNumbers(int length, int max, int min){
		int[] temp = new int[length];
		for(int i=0;i<temp.length;i++) {
			temp[i]=(int)(Math.random()*(max-min+1)+min);
		}
		return temp;
	}//end randomNumbers
	
	/**
	 * Pre:intArray
	 * @param x
	 * 
	 * Post:
	 * @return the sum of every integer inside the array
	*/
	
	public static int sumArray(int[] x) {
		int[] temp = new int[x.length];
		temp = x;
		int sum = 0;
		for(int i=0;i<temp.length;i++) {
			sum += temp[i];
		}
		return sum;
	}
	
	/** 
	 * Pre:intArray
 	 * @param x
	 * 
	 * Post:
	 * @return the smallest number in intArray
	*/
	
	public static int findMinimum(int[] x) {
		int min=0;;
		for(int i=0;i<x.length-1;i++) {
			if (x[i] < x[i+1])
				min = x[i];
			else
				min=x[i+1];
		}
		return min;
	}
	
	/**
	 * Pre: intArray
	 * @param x
	 * 
	 * Post:
	 * @return the largest value inside intArray
	*/
	
	public static int findMaximum(int[] x) {
		int max=0;;
		for(int i=0;i<x.length-1;i++) {
			if (x[i] > x[i+1])
				max=x[i];
			else 
				max=x[i+1];
		}
		return max;
	}
	
	/**
	 * Pre: intArray
	 * @param x
	 * 
	 * Post:
	 * @return
	 */
	
	public static double findAverage(int[] x) {
		double avg=0;
		for(int i=0;i<x.length;i++) {
			avg += x[i];
		}
		avg/=x.length;
		return avg;
	}
	
	/**
	 * Pre: intArray
	 * @param x
	 * 
	 * Post:
	 * @return a boolean stating if a number repeats or not
	*/
	
	public static boolean isRepeated(int[] x) {
		boolean z=false;
		for(int i=0;i<x.length;i++){
			for(int k=x.length-1;k>i;k--) {
				if(x[i]==x[k]) {
					z=true;
				}
			}
		}
		return z;
	}
	
	/**
	 * Pre: intArray
	 * @param x
	 * 
	 * Post:
	 * @return an array saying if each position is odd or even
	 */

	public static int[] oddOrEvens(int[] x) {
		int[] temp = new int[x.length];
		for(int i=0;i<x.length;i++) {
			if(x[i]%2==0)
				temp[i]=1;
			else
				temp[i]=0;
		}
		
		return temp;
	}
	
	/**
	 * pre: intArray, divideNumber
	 * @param x
	 * @param number
	 * 
	 * Post:
	 * @return an array stating if each element of intArray is divisible by divideNumber
	 */
	
	public static int[] isDivisible(int[] x, int number) {
		int[] temp=new int[x.length];
		for(int i=0;i<x.length;i++) {
			if(x[i]%number==0)
				temp[i]=1;
			else
				temp[i]=0;
		}
		return temp;
	}
	
	/**
	 * Pre:an array
	 * @param x
	 * 
	 * Post: print out the array
	 * 
	 */
	
	public static void printArray(int[] x) {

		for(int i=0;i<x.length;i++) {
			System.out.print(x[i] + " ");
		}
		System.out.println();
	}

	/**
	 * Pre: intArray 
	 * @param x
	 * 
	 * Post:
	 * @return a copy of intArray
	 */
	
	public static int[] makeCopy(int[] x) {
		int[] temp = new int[x.length];
		for(int i=0;i<x.length;i++) {
			temp[i]=x[i];
		}
		return temp;
	}
	
	/**
	 * Pre: intArray
	 * @param x
	 * 
	 * Post: 
	 * @return an array that is intArray reversed
	 */
	
	public static int[] makeReverse(int[] x) {
		int[] temp = new int[x.length];
		for(int i=0;i<x.length;i++) {
			temp[i]=x[x.length-i-1];
		}
		return temp;
	}
	
	
}