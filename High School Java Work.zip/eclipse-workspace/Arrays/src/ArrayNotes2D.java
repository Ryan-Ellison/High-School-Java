
public class ArrayNotes2D {

	public static void main(String[] args) {
		int[][] arr=new int[3][5];//makes an array that is 3x5(3 rows 5 columns)
		//rows = arr.length
		//columns = arr[0].length;
		//if 3 dimensional, keep on adding [0]
		rowMajorOrder(arr);
	}
	
	
	/**
	 * Pre:a 2D array
	 * @param arr
	 * Post: Prints each element of the array in a grid, seperated by 2 spaces
	 */
	
	public static void rowMajorOrder(int[][] arr) {
		for(int i=0;i<arr.length;i++) {//rows
			for(int j=0;j<arr[0].length;j++) {//columns
				System.out.print(arr[i][j]+"  ");
			}
			System.out.println();
		}
		System.out.println();
	}

}
