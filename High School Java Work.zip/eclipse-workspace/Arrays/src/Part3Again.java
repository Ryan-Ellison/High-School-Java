import java.util.Scanner;

public class Part3Again {
	
	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		int number=in.nextInt();
		in.close();
		System.out.println(intLength(number));
		int[] array=new int[intLength(number)];
		array=fillArray(number);
		ArrProject.printArray(array);
	}
	
	public static int intLength(int number) {
		int temp=Integer.toString(number).length();
		return temp;
	}
	
	public static int[] fillArray(int number) {
		String string=Integer.toString(number);
		int[] temp=new int[intLength(number)];
		for(int i=0;i<intLength(number);i++) {
			temp[i]=(int)(string.charAt(i))-48;
		}
		return temp;
	}
	

}

