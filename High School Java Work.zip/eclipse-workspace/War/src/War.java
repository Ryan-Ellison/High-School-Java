import java.util.Random;
import java.util.Scanner;
public class War {

	public static void main(String[] args) {
		String baseDeck = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
		int inp=-1;
		String playerDeck1 = "";
		String playerDeck2 = "";
		playerDeck1 = fillDeck1(baseDeck);
		playerDeck2 = fillDeck2(playerDeck1,baseDeck);
		int warRepeats=0;
		int winner=0;
		int warWinner=0;
		while (inp!=2 && playerDeck1.length() < 52 && playerDeck2.length() < 52) {
			menu();
			Scanner in = new Scanner(System.in);
			inp=in.nextInt();
			if (inp==1) {
				winner=play(playerDeck1,playerDeck2);
				if(winner==0) {
					System.out.println("Player 1 wins this round!");
					playerDeck1=playerGetCards(playerDeck1,playerDeck2);
					playerDeck2=playerLoseCards(playerDeck2);
				}//end player1winning
				else if(winner==1){
					System.out.println("Player 2 wins this round!");
					playerDeck2=playerGetCards(playerDeck2,playerDeck1);
					playerDeck1=playerLoseCards(playerDeck1);
				}//end player2winning
				else {
					System.out.println("WAR");
					warRepeats=0;
					warWinner=0;
					while(warWinner!=2) {
						if(warWinner==0) {
							System.out.println("Player 1 wins this round!");
							for(int i=0;i<3;i++) {
								playerDeck1=playerGetCards(playerDeck1,playerDeck2);
								playerDeck2=playerLoseCards(playerDeck2);
							}//end card change
							warWinner=2;
						}//end if player1 wins
						else if(warWinner==1) {
							System.out.println("Player 2 wins this round!");
							for(int i=0;i<3;i++) {
								playerDeck2=playerGetCards(playerDeck1,playerDeck2);
								playerDeck1=playerLoseCards(playerDeck2);
							}//end card change
							warWinner=2;
						}//end if player2 wins
						warRepeats+=3;
					}//end while war
				}//end if war occurs
				System.out.println("Player 1 deck length: " + playerDeck1.length());
				System.out.println("Player 2 deck length: " + playerDeck2.length());
				System.out.println();			
				System.out.println();
			}
		}//playing
		System.out.println("Game over!");
	}//end main
	
	public static String fillDeck1(String baseDeck) {
	String playerDeck="";
	int a=0;
		for(int i=0;i<26;i++) {
			a=(int)((Math.random() * baseDeck.length())-1);
			playerDeck+=baseDeck.charAt(a);
			baseDeck=baseDeck.substring(0,a)+ baseDeck.substring((a+1),(baseDeck.length()));
		}//end for loop
	return playerDeck;
	}//end fillDeck1
	
	public static String fillDeck2(String deck1,String baseDeck) {
		String deck2="";
		for(int i=0;i<52;i++) {
			if(!deck1.contains(baseDeck.substring(i, i+1))) {
				deck2+=baseDeck.charAt(i);
			}
		}//end for loop
		return deck2;
	}//end fillDeck2
	
	public static void menu() {
		System.out.println("Press 1 to play your cards");
		System.out.println("Press 2 to end the game and leave");
	}

	public static int play(String player1, String player2){
		int card1=(int)(player1.charAt(0));
		int card2=(int)(player2.charAt(0));
		printCards(card1,card2);
		if (card1%13==1 && card2%13!=1) {
			return 0;
		}//end player 1 ace
		else if (card2%13==1 && card1%13!=1) {
			return 1;
		}//end player 2 ace
		else if (card1%13==0&&card2%13!=0) {
			return 0;
		}
		else if (card2%13==0&&card1%13!=0) {
			return 1;
		}
		else if (card1%13>card2%13) {
			return 0;
		}//end player 1 > no ace
		else if (card2%13>card1%13) {
			return 1;
		}//end player 2 > no ace
		return 2;
	}
	
	public static int war(String player1, String player2, int repeats) {
		int card1=(int)(player1.charAt(3+repeats));
		int card2=(int)(player2.charAt(3+repeats));
		System.out.println();
		System.out.println();
		printCards(card1,card2);
		if (card1%13==1 && card2%13!=1) {
			return 0;
		}//end player 1 ace
		else if (card2%13==1 && card1%13!=1) {
			return 1;
		}//end player 2 ace
		else if (card1%13==0&&card2%13!=0) {
			return 0;
		}
		else if (card2%13==0&&card1%13!=0) {
			return 1;
		}
		else if (card1%13>card2%13) {
			return 0;
		}//end player 1 > no ace
		else if (card2%13>card1%13) {
			return 1;
		}//end player 2 > no ace
		return 2;
	}

	public static void printCards(int card1, int card2) {
		switch (card1%4) {
			case 0: System.out.print("Hearts");
			break;
			case 1: System.out.print("Diamonds");
			break;
			case 2: System.out.print("Spades");
			break;
			case 3: System.out.print("Clubs");
			break;
		}//end switch
		System.out.print("     ");
		switch (card2%4) {
			case 0: System.out.println("Hearts");
			break;
			case 1: System.out.println("Diamonds");
			break;
			case 2: System.out.println("Spades");
			break;
			case 3: System.out.println("Clubs");
			break;
		}//end switch2
		if (card1%13>1&&card1%13<11) {
			System.out.print(card1%13);
		}//end 1-10
		if (card1%13==11) {
			System.out.print("Jack");
		}//card1 jack
		if (card1%13==12) {
			System.out.print("Queen");
		}//card1 queen
		if (card1%13==0) {
			System.out.print("King");
		}//card1 king
		if (card1%13==1) {
			System.out.print("Ace");
		}//card1 ace
		System.out.print("         ");
		if (card2%13>1&&card2%13<11) {
			System.out.println(card2%13);
		}//end 1-10
		if (card2%13==11) {
			System.out.println("Jack");
		}//card2 jack
		if (card2%13==12) {
			System.out.println("Queen");
		}//card2 queen
		if (card2%13==0) {
			System.out.println("King");
		}
		if (card2%13==1) {
			System.out.println("Ace");
		}
	}//end printCards
	
	public static String playerGetCards(String playerDeck1, String playerDeck2) {
		playerDeck1 = playerDeck1.substring(1, playerDeck1.length()) +playerDeck1.charAt(0)+playerDeck2.charAt(0);
		return playerDeck1;
	}//end player1GetCards
	
	public static String playerLoseCards(String playerDeck2) {
		playerDeck2=playerDeck2.substring(1, playerDeck2.length());
		return playerDeck2;
	}//end player2LoseCards
	
	
}//end class
