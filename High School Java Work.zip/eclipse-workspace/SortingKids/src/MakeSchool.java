
public class MakeSchool {

	public static void main(String[] args) {
		Basic bro=new Basic();
		bro.addRoster(bro);

		Involved citizen = new Involved(true, 11.5, "Professional Student");
		citizen.addRoster(citizen);
		
		Interesting paco=new Interesting(true, 12.0, "Curling", "reee");
		paco.addRoster(paco);
		
		absStud.printRoster();
	}

}
