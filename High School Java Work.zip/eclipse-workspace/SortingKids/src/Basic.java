import java.util.*;
public class Basic extends absStud{

	private boolean pulse;
	private double gpa;
	private ArrayList<Double> status;
	
	public Basic() {
		setPulse(true);
		setGpa(6.5);
		setStatus(new ArrayList<Double>());
	}
	
	public Basic(boolean a, double b) {
		setPulse(a);
		setGpa(b);
		this.status=new ArrayList<Double>();
	}

	public void showMe() {
		System.out.println("Sup :)");
		System.out.println("I am me");
		System.out.println("Heart: " + this.isPulse());
		System.out.println("Grades like: " + this.getGpa());
		System.out.println("I'm like: " + this.getStatus());
		System.out.println();
		System.out.println();
	}
	
	public boolean isPulse() {
		return pulse;
	}

	public void setPulse(boolean pulse) {
		this.pulse = pulse;
	}

	public double getGpa() {
		return gpa;
	}

	public void setGpa(double gpa) {
		this.gpa = gpa;
	}

	public ArrayList<Double> getStatus() {
		return status;
	}

	public void setStatus(ArrayList<Double> status) {
		this.status = status;
	}
}
