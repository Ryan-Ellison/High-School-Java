import java.util.*;

public class Drive {
	
	public static final int GSIZE = 15;
	
	public static void main(String[] args) {
		ArrayList<ArrayList<Double>> group=new ArrayList<ArrayList<Double>>();
		group=create(20,0,0,group);
		//group=create(group);
		group=addStatus(group);
		for(int i=0;i<1500;i++) {
			group=runGroup(group);
			group=swap(group);
			if((i+1)%500==0) {
				group=round(group);
				if(i!=1499)
					group=addStatus(group);
			}
		}
		int[][] transition=new int[3][3];
		fillTransition(transition,group);
		//System.out.println(group);
		for(int i=0;i<transition.length;i++) {
			System.out.println();
			for(int j=0;j<transition[0].length;j++) {
				System.out.print(transition[i][j]+" ");
			}
		}
		
		
		
	}
	
	private static void fillTransition(int[][] transition, ArrayList<ArrayList<Double>> group) {
		for(ArrayList<Double> student: group) {
			transition[(int) (student.get(0)-1)][(int) (student.get(student.size()-1)-1)]++;
		}
		
	}

	private static ArrayList<ArrayList<Double>> round(ArrayList<ArrayList<Double>> group) {
		for(ArrayList<Double> student : group) {
			student.set(student.size()-1, (double) Math.round(student.get(student.size()-1)));
		}
		return group;
	}

	private static ArrayList<ArrayList<Double>> addStatus(ArrayList<ArrayList<Double>> group) {
		for(ArrayList<Double> student : group) {
			student.add(student.get(student.size()-1));
		}
		return group;
	}

	private static ArrayList<ArrayList<Double>> runGroup(ArrayList<ArrayList<Double>> group) {
		/** double temp;
		for(int i=1;i<group.size()-1;i++) {
			temp=(double) group.get(i).get(group.get(i).size()-1);
			if(((Double) group.get(i-1).get(group.get(i).size()-2)).doubleValue()<2.0&&((Double) group.get(i+1).get(group.get(i).size()-2)).doubleValue()<2) {
				group.get(i).set(((group.get(i).size()-1)),(Double)(temp-0.2));
			}
			else if(((Double)group.get(i-1).get(group.get(i).size()-2)).doubleValue()<2.0&&((Double)group.get(i+1).get(group.get(i).size()-2)).doubleValue()>2) {
				group.get(i).set(((group.get(i).size()-1)),(Double)(temp+0.1));
			}
		}**/
		for(int i=1;i<group.size()-1;i++) {
			if(group.get(i-1).get(group.get(i).size()-2)<2&&group.get(i+1).get(group.get(i).size()-2)<2) {
				group.get(i).set(group.get(i).size()-1, ((group.get(i).get(group.get(i).size()-1)-0.2)));
			}
			else if(group.get(i-1).get(group.get(i).size()-2)>2&&group.get(i+1).get(group.get(i).size()-2)>2) {
				group.get(i).set(group.get(i).size()-1, ((group.get(i).get(group.get(i).size()-1)+0.1)));
			}
			if(group.get(i).get(group.get(i).size()-1)>3){
				group.get(i).set(group.get(i).size()-1, 3.0);
			}
			else if(group.get(i).get(group.get(i).size()-1)<1){
				group.get(i).set(group.get(i).size()-1, 1.0);
			}
		}
		return group;
	}

	public static ArrayList<ArrayList<Double>> create(ArrayList<ArrayList<Double>> group) {
		for(int i=0;i<GSIZE;i++) {
			ArrayList<Double> student=new ArrayList<Double>();
			student.add(1.0*(int)(Math.random()*3+1));
			group.add(student);
		}
		return group;
	}
	
	public static ArrayList<ArrayList<Double>> create(double one, double two, double three, ArrayList<ArrayList<Double>> group){
		for(int i=0; i<(GSIZE*one/100);i++) {
			ArrayList<Double> student=new ArrayList<Double>();
			student.add(1.0);
			group.add(student);
		}
		for(int i=0; i<(GSIZE*two/100);i++) {
			ArrayList<Double> student=new ArrayList<Double>();
			student.add(2.0);
			group.add(student);
		}
		int size=group.size();
		for(int i=0;i<GSIZE-size;i++) {
			ArrayList<Double> student=new ArrayList<Double>();
			student.add(3.0);
			group.add(student);	
		}
		swap(group);
		return group;
		
	}

	public static ArrayList<ArrayList<Double>> swap(ArrayList<ArrayList<Double>> group){
		for(int i=0;i<(int)(GSIZE/2)+1;i++) {
			group.add(group.remove((int)(Math.random()*GSIZE)));
		}
		return group;
		
	}

}
