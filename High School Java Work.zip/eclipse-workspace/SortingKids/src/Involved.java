
public class Involved extends Basic{
	
	private String club;
	
	public Involved(boolean p, double g,String c) {
		super(p, g);
		setClub(c);
	}
	
	public void showMe() {
		super.showMe();
		System.out.println("I'm an active member of " + this.club);
	}

	public String getClub() {
		return club;
	}

	public void setClub(String club) {
		this.club = club;
	}


}
