
public class Interesting extends Involved{
	
	private String hobby;
	
	public Interesting(boolean p, double ga, String c, String h) {
		super(p,ga,c);
		this.hobby=h;
	}
	
	public void showMe() {
		super.showMe();
		System.out.println("I like to " + this.hobby+" in my free time.");
	}

}
