import java.util.ArrayList;

public abstract class absStud {
	
	private static int numStuds=0;
	private static ArrayList<Basic> roster = new ArrayList<Basic>();
	
	public abstract void showMe();	
	
	public void addRoster(Basic b) {
		roster.add(b);
		numStuds++;
	}
	
	public static void printRoster() {
		for(Basic b:roster) {
			b.showMe();
		}
		
		System.out.println("How many stoodents? "+numStuds);
	}

}
