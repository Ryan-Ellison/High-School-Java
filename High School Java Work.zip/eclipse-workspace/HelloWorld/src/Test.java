
public class Test {
	
	public static void main (String[] args) {
		String str = "hello";
		char x = 'a';
		str+=x;
		System.out.println(str);
		}
}