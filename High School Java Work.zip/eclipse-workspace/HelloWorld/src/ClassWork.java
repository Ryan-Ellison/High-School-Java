
public class ClassWork {

	public static void main(String[] args) {
		String str1="CB South";
		String str2="Titan";
		String str3="football";
		
		System.out.println(str1.toLowerCase());
		System.out.println(str3.equalsIgnoreCase(str1));
		System.out.println(str2.compareTo(str3));
	}
}
