
public class LoopPractice {
	
	public static void main(String[] args) {
		partOne();
		partTwo();
		partThree();
		partFour();
		}//end void main
		
	public static void partOne() {
		for(int i=1;i<11;i++) {//1st is variable, then condition, then what happens at the end
			System.out.println(i);
		}//end for loop
	}//end part one
	public static void partTwo() {
		for(int i=2;i<8;i++) {
			System.out.print(i + " ");
		}// end for loop
		System.out.println();
	}//end part two
	public static void partThree() {
		for(int i=83;i<97;i++) {
			System.out.print(i + ", ");
		}//end for loop
		System.out.println("97");
	}//end part three
	public static void partFour() {
		int a = 0;
		for(int i=-6;i<15;i++) {
			System.out.print(i + " ");
			a++;
			if (a%3==0){
				System.out.println();
			}
		}//end for loop
	}//end part four
}// end class

