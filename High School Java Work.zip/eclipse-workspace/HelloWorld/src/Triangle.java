/*
 * Ryan Ellison
 * 1/29/18
 * Program description:
 * This program determines whether a triangle is valid and then provides a description and the area.
 * Pre: a, b, c represent the possible sides of a triangle
 * Post: determines if valid and ten classifies as acute, obtuse, or right and then gives the area.
 * 		if its right then it also finds the hypotenuse
 */
import java.util.*;

public class Triangle {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		int a=in.nextInt();
		int b=in.nextInt();
		int c=in.nextInt();	
		in.close();
		int side1=0;
		int side2=0;
		int largest = findLargest(a,b,c);
		if (a==largest) {
			side1=b;
			side2=c;
		}
		else if (b==largest) {
			side1=a;
			side2=c;
		}
		else if (c==largest) {
			side1=a;
			side2=b;
		}

		
		if (isValidTri(largest, side1, side2)) {
			System.out.println("Valid triangle");
			System.out.println(describeTri(largest, side1, side2));
			outputDescript(describeTri(largest, side1, side2));
			System.out.println("The area of the triangle is: " + areaTri(largest, side1, side2));
			System.out.println("The Semiperimeter of the triangle is: " + semiPerTri(largest,side1,side2));
			if (describeTri(largest, side1, side2) == 2) {
				System.out.println("The length of the hypotenuse is: " + largest);
			}//if right
		}//if valid triangle
		else
			System.out.println("The shape is invalid");

		
	}
	
	//find the largest side of the triangle
	public static int findLargest(int a,int b,int c) {
		if (a>b && a>c)
			return a;
		else if (b>a && b>c)
			return b;
		else 
			return c;
	}
	//find if the triangle is valid
	public static boolean isValidTri(int a1, int b1, int c1) {
		if (b1 + c1 > a1)
			return true;
		else
			return false;
	}
	//determine the kind of triangle it is
	public static int describeTri(int a1,int b1,int c1) {
		if (((b1*b1) + (c1*c1)) == (a1*a1))	
			return 2;
		else if (((b1*b1) + (c1*c1)) < (a1*a1))
			return 1;
		else 
			return 0;
	}
	//state what kind of triangle it is
	public static void outputDescript(int d1) {
		if (d1 == 2)
			System.out.println ("The triangle is right");
		else if (d1 == 1)
			System.out.println ("The triangle is obtuse");
		else
			System.out.println ("The triangle is acute");
		
	}
	//calculate the area of the triangle
	public static double areaTri(int a1, int b1, int c1) {
		double semiPer = semiPerTri(a1,b1,c1);
		return (Math.sqrt((semiPer-a1)*(semiPer-b1)*(semiPer-c1)*semiPer));
	}
	//find the Semiperimeter of the triangle
	public static double semiPerTri(int a1, int b1, int c1) {
		return (a1+b1+c1)/2.0;
	}
}
