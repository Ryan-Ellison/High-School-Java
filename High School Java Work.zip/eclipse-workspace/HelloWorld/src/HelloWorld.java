/*Ryan Ellison
 * 1/11/18
 * 
 * Program Description:
 * Print "Hello World", then state the sum of X and Y */
public class HelloWorld {
	public static void main(String[] args) {
		System.out.println("Hello world!");
		double x = 1.2;
		double y = 3.4;
		double sum = x + y;
		System.out.println("The sum = " + sum);
	}//end main
}//end class HelloWorld
