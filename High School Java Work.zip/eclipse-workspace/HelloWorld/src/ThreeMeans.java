/*
 * Ryan Ellison
 * 1/29/18
 * Program description:
 * Find the arethmetic, geometric, and harmonic means
 */

public class ThreeMeans {

	public static void main(String[] args) {
		
		int a=45;
		int b=24;
		int c=11;
		
		double arithmeticMean = calcAMean(a,b,c);
		double geometricMean = calcGMean(a,b,c);
		double harmonicMean = calcHMean(a,b,c);
		
		outputVars(a,b,c);
		outputMeans(arithmeticMean, geometricMean, harmonicMean);

	}
	
	public static void outputVars(int a2,int b2,int c2) {
		System.out.println("a: " + a2);
		System.out.println("b: " + b2);
		System.out.println("c: " + c2);
		
	}// end class outputVars Method
	
	public static double calcAMean (int a2,int b2,int c2) {
		return (double)(a2+b2+c2)/3; //(double) casts the equation as a double
	}//calculate ArithmeticMean
	
	public static double calcGMean(int a2,int b2,int c2) {
		return Math.cbrt(a2*b2*c2);
	}//calculate geometric mean
	
	public static double calcHMean(int a2,int b2,int c2) {
		return 3.0/((1.0/a2)+(1.0/b2)+(1.0/c2)); //by putting a .0 after numbers it becomes a double
	}//calculate HarmonicMean
	
	public static void outputMeans(double arithmeticMean, double geometricMean, double harmonicMean){
		
		System.out.println("ArithmeticMean: " + arithmeticMean);
		System.out.println("GeometricMean: " + geometricMean);
		System.out.println("HarmonicMean: " + harmonicMean);
		
	}// ends outputMeans
	

}//end class
