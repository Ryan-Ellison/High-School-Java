
public class Bases {

	public static void main(String[] args) {
		String aNum="XYZ";
		int aBase=21;
		String bNum="0";
		int bBase=10;
		String newNum="";
		int cBase=20;
		String resultNum="";
		int resultBase=aBase;
		int holder=0;
		holder=convertTen(aNum,aBase);
		newNum=convertFromTen(holder, cBase);
		outputs(aNum,aBase,newNum,cBase,holder);
		resultBase=aBase;
		resultNum=addNums(aNum,aBase,bNum,bBase);
		resultNum=multiplyNums(aNum,aBase,bNum,bBase);
		
	}

	/**
	 * Pre: a String and an int, representing a number and a base
	 * @param num
	 * @param base
	 * @return that number in base 10
	 */
	
	public static int convertTen(String num, int base) {
		int temp=0;
		int count=0;
		for(int i=num.length()-1;i>=0;i--) {
			if(((int)(num.charAt(count)))>=65) {
				temp+=(((int)num.charAt(count))-55)*Math.pow(base,i);
			}
			else {
				temp+=(((int)num.charAt(count))-48)*Math.pow(base,i);
			}
			count++;
		}
		return temp;
	}
	
	/**
	 * Pre: an int with a number in base 10, and a base to convert it to
	 * @param num
	 * @param base
	 * @return a String with the number in our new base
	 */
	
	public static String convertFromTen(int num, int base) {
		int temp=0;
		String result="";
		while(num>0) {
			temp=num%base;
			if(temp>=10) {
				result=((char)(temp+55))+result;
			}
			else
				result=temp+result;
			num/=base;
			num=(int)num;
		}
		if (result.equals(""))
			return "0";
		return result;
	}

	/**
	 * Pre: two Strings holding numbers, and ints representing the bases each should be in
	 * @param aNum
	 * @param aBase
	 * @param bNum
	 * @param bBase
	 * @return a String representing these numbers added in the 1st base
	 */
	
	public static String addNums(String aNum, int aBase, String bNum, int bBase) {
		int temp1=convertTen(aNum,aBase);
		int temp2=convertTen(bNum,bBase);
		int answer=temp1+temp2;
		String stringAnswer="";
		stringAnswer=convertFromTen(answer,aBase);
		System.out.println("The numbers added together are: "+stringAnswer+" (base "+aBase+")");
		return stringAnswer;
	}
	
	/**
	 * Pre; two Strings holding numbers, and ints representing the bases each should be in
	 * @param aNum
	 * @param aBase
	 * @param bNum
	 * @param bBase
	 * @return these two Strings multiplied in the base of the 1st String
	 */
	
	public static String multiplyNums(String aNum, int aBase, String bNum, int bBase) {
		int temp1=convertTen(aNum,aBase);
		int temp2=convertTen(bNum,bBase);
		int answer=temp1*temp2;
		String stringAnswer="";
		stringAnswer=convertFromTen(answer,aBase);
		System.out.println("The numbers multiplied together are: "+stringAnswer+" (base "+aBase+")");
		return stringAnswer;
	}
	
	/**
	 * Pre: two Strings, two ints representing their bases, and an int representing the first in base 10
	 * @param aNum
	 * @param aBase
	 * @param bNum
	 * @param bBase
	 * @param holder
	 * Post; all of these are printed out and labelled
	 */
	
	public static void outputs(String aNum, int aBase, String bNum, int bBase, int holder) {
		System.out.println(aNum+" (base "+aBase+") in base 10 is:");
		System.out.println(holder);
		System.out.println("This number in base "+bBase+" is:");
		System.out.println(bNum);
	}

}
