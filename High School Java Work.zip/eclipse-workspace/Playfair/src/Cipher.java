import java.util.Scanner;

public class Cipher {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String key;
		String okey;
		String[][] arr=new String[5][5];
		String message;
		String oMessage;
		String[] pairs;
		okey=makeKey(sc);
		key=editKey(okey);
		oMessage=makeMessage(sc);
		message=editMessage(oMessage);
		String[] pairs2;
		arr=new String[5][5];
		fillArr(key, arr);
		pairs=new String[createPairs(message)];
		splitPairs(pairs,message);
		pairs2=new String[pairs.length];
		String redo="";
		if(encyrptDecrypt(sc).equals("encrypt")) {
			encrypt(pairs,arr);
			for(int i=0;i<pairs.length;i++) {
				redo+=pairs[i];
			}
			splitPairs(pairs2,redo);
			decrypt(pairs2,arr);
		}
		else {
			decrypt(pairs,arr);
			for(int i=0;i<pairs.length;i++) {
				redo+=pairs[i];
			}
			splitPairs(pairs2,redo);
			encrypt(pairs2,arr);
		}
		outputs(key,okey,oMessage,arr,message,pairs,pairs2);
	}
	
	public static void outputs(String key,String okey, String omessage, String[][] array, String message, String[] pair,String[] pairs2) {
		System.out.println("The original key is: "+okey);
		System.out.println("The adjusted key is: "+key);
		for(int i=0;i<array.length;i++) {
			for(int j=0;j<array[0].length;j++) {
				System.out.print(array[i][j]+" ");
			}
			System.out.println();
		}
		System.out.println("The original message is: "+omessage);
		System.out.println("The adjusted message is: "+message);
		System.out.print("The encryped message is: ");
		for(int i=0;i<pair.length;i++) {
			System.out.print(pair[i]+" ");
		}
		System.out.println();
		System.out.print("That message decrypted is: ");
		for(int i=0;i<pair.length;i++) {
			System.out.print(pairs2[i]+" ");
		}
	}
	
	private static int createPairs(String message) {
		if(message.length()%2==0)
			return message.length()/2;
		else
			return (int)(message.length()/2)+1;
		
	}

	public static String encyrptDecrypt(Scanner sc) {
		System.out.println("Would you like to encrypt or decrypt?");
		String message = sc.nextLine();
		return message;
	}

	private static String makeKey(Scanner sc) {
		System.out.println("Enter the key:");
		String key=sc.nextLine();
		return key;
	}
	
	private static String editKey(String key) {
		key=key.toLowerCase();
		key=removeDuplicates(key);
		key=removeSpaces(key);
		return key;
	}

	private static String makeMessage(Scanner sc) {
		System.out.println("Enter the message to encrypt/decrypt:");
		String message=sc.nextLine();
		return message;
	}

	private static String editMessage(String message) {
		message=message.toLowerCase();
		message=removeSpaces(message);
		for(int i=0;i<message.length();i++){
			if(message.substring(i, i+1).equals("q")) {
				message=message.substring(0,i)+"p"+message.substring(i+1);
			}
		}
		return message;
	}
	
	public static void encrypt(String[] pairs, String[][] key) {
		String one="";
		String two="";
		for(int i=0;i<pairs.length;i++) {
			one=pairs[i].substring(0, 1);
			two=pairs[i].substring(1);
			if(one.equalsIgnoreCase(two)) {
				two="x";
			}
			if(findColumn(one,key)==findColumn(two,key)) {
				pairs[i]=key[(findRow(one,key)+1)%5][findColumn(one,key)]+key[(findRow(two,key)+1)%5][findColumn(two,key)];
			}
			else if(findRow(one,key)==findRow(two,key)) {
				pairs[i]=key[findRow(one,key)][(findColumn(one,key)+1)%5]+key[findRow(two,key)][(findColumn(two,key)+1)%5];
			}
			else {
				pairs[i]=key[findRow(one,key)][findColumn(two,key)]+key[findRow(two,key)][findColumn(one,key)];
			}
		}
	}
	
	public static void decrypt(String[] pairs, String[][] key) {
		String one="";
		String two="";
		for(int i=0;i<pairs.length;i++) {
			one=pairs[i].substring(0, 1);
			two=pairs[i].substring(1);
			if(one.equalsIgnoreCase(two)) {
				two="x";
			}
			if(findColumn(one,key)==findColumn(two,key)) {
				pairs[i]=key[(findRow(one,key)+4)%5][findColumn(one,key)]+key[(findRow(two,key)+4)%5][findColumn(two,key)];
			}
			else if(findRow(one,key)==findRow(two,key)) {
				pairs[i]=key[findRow(one,key)][(findColumn(one,key)+4)%5]+key[findRow(two,key)][(findColumn(two,key)+4)%5];
			}
			else {
				pairs[i]=key[findRow(one,key)][findColumn(two,key)]+key[findRow(two,key)][findColumn(one,key)];
			}
		}
	}
	
	public static int findColumn(String str,String[][] key) {
		int col=0;
		for(int i=0;i<key.length;i++) {
			for(int j=0;j<key[0].length;j++) {
				if(str.equals(key[i][j]))
					col=j;
			}
		}
		//System.out.println("col: "+ col);
		return col;
	}
	
	public static int findRow(String str,String[][] key) {
		int row=0;
		for(int i=0;i<key.length;i++) {
			for(int j=0;j<key[0].length;j++) {
				if(str.equals(key[i][j]))
					row=i;
			}
		}
		//System.out.println("row: "+row);
		return row;
	}
	
	public static void splitPairs(String[] pairs, String message) {
		int temp=0;
		for(int i=0;i<pairs.length;i++) {
			pairs[i]="";
		}
		for(int i=0;i<message.length();i++) {
			pairs[(int)(i/2)]+=message.substring(i, i+1);
		}
		if(pairs[pairs.length-1].length()==1) {
			pairs[pairs.length-1]+="z";
		}
	}

	public static void fillArr(String key, String[][] arr) {
		int temp=0;
		String abc="abcdefghijklmnoprstuvwxyz";
		abc=removeSpare(key,abc);
		int count=0;
		boolean exist=false;
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[0].length;j++) {
				if(temp<key.length())
					arr[i][j]=key.substring(temp, temp+1);
				else {
					arr[i][j]=abc.substring(count, count+1);
					count++;
				}
				temp++;
			}
		}
	}

	public static void fillArr(String key, String[][] arr) {
		int temp=0;
		String abc="abcdefghijklmnoprstuvwxyz";
		abc=removeSpare(key,abc);
		int count=0;
		boolean exist=false;
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[0].length;j++) {
				if(temp<key.length())
					arr[i][j]=key.substring(temp, temp+1);
				else {
					arr[i][j]=abc.substring(count, count+1);
					count++;
				}
				temp++;
			}
		}
	}

	public static String removeSpare(String key, String abc) {
		for(int i=0;i<abc.length();i++) {
			if(key.indexOf(abc.substring(i, i+1))!=-1) {
				abc=abc.substring(0,i)+abc.substring(i+1);
				i--;
			}
		}
		return abc;
	}

	public static String removeSpaces(String key) {
		for(int i=0;i<key.length();i++) {
			if(!Character.isLetter(key.charAt(i))) {
				key=key.substring(0, i)+key.substring(i+1);
			}
		}
		return key;
	}
	
	public static String removeDuplicates(String key) {
		for(int i=0;i<key.length();i++) {
			if((key.indexOf(key.substring(i,i+1))!=i)) {
				key=key.substring(0, i)+key.substring(i+1);
				i--;
			}
		}
		return key;
	}


}
