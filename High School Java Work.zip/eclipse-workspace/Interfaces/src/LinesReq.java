//its all public !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! WOW
public interface LinesReq {
	public double getSlope();
	public double getXInt();
}


