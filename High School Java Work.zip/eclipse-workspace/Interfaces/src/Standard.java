
public class Standard implements LinesReq{
	
	double a;
	double b;
	double c;
	
	public Standard(double a1, double b1, double c1) {
		a=a1;
		b=b1;
		c=c1;
	}
	
	public double getSlope() {
		return (-a/b);
	}
	
	public double getXInt() {
		return (c/a);
	}
	


}
