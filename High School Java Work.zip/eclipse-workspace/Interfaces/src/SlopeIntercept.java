//do what the interface says
public abstract class SlopeIntercept implements LinesReq{
	private double slope;
	private double yInt;
	public SlopeIntercept(double slope1, double y) {
		slope=slope1;
		yInt=y;
	}
	
	public void printMessage() {
		System.out.println("I am specific to Slope Intercept");
	}
	
	public double getSlope() {
		return slope;
	}

	public abstract double getXInt();
	
}