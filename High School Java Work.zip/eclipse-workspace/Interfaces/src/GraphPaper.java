
public class GraphPaper {
	public static void main(String[] args) {
		//Standard line=new Standard(5,5,5);
		SlopeIntercept line=new SlopeIntercept(1,5);
		//System.out.println(line.getSlope());
		//System.out.println(line.getXInt());
		printStuff(line);
	}
	
	public static void printStuff(LinesReq slope) {
		System.out.println(slope.getSlope());
	}
}
