import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class TicTacToe extends JFrame implements ActionListener {

	JPanel panel;
	JButton[] button;
	int count = 0;
	int sign = 0;

	public TicTacToe() {
		panel = new JPanel();
		panel.setPreferredSize( new Dimension(2060, 1280));
		panel.setLayout(new GridLayout(3, 3));
		this.add(panel);
		button = new JButton[9];
		for (int i = 0; i <= 8; i++) {
			button[i] = new JButton();
			panel.add(button[i]);
			button[i].setText(" ");
			button[i].setEnabled(true);
			button[i].addActionListener(this);
			for(int k=0;k<i;k++) {
				button[i].setText(button[i].getText()+(" "));
			}
		}
		this.pack();
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {
		count++;
		for (int i = 0; i <= 8; i++) {
			if (button[i] == e.getSource()) {
				if (sign % 2 == 0) {
					button[i].setText("X");
				} else {
					button[i].setText("O");
				}
				button[i].setEnabled(false);
			}
		}
		if (count >= 9) {
			JOptionPane.showMessageDialog(null, "Cat's Game!");
			dispose();
			new TicTacToe();
		}
		sign++;
		if(checkWinner()) {
			if(sign%2==0)
				JOptionPane.showMessageDialog(null,"O Wins!");
			else
				JOptionPane.showMessageDialog(null,"X Wins!");
			dispose();
			new TicTacToe();
		}
	}

	public boolean checkWinner() {
		for(int i=0;i<3;i++) {
			if(button[i*3].getText().equals(button[i*3+1].getText())&&button[i*3].getText().equals(button[i*3+2].getText())) {
				return true;
			}
			else if(button[i].getText().equals(button[i+3].getText())&&button[i].getText().equals(button[i+6].getText())){
				return true;
			}
		}
		if(button[0].getText().equals(button[4].getText())&&button[0].getText().equals(button[8].getText())){
			return true;
		}
		else if(button[2].getText().equals(button[4].getText())&&button[2].getText().equals(button[6].getText())){
			return true;
		}
		return false;
	}

	public static void main(String args[]) {
		new TicTacToe();
	}
}
