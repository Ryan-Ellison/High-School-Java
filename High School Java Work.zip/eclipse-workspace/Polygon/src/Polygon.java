
public class Polygon {
	int[][] vertex;
	int numSides;
	double perimeter;
	double area;
	double[] centroid;
	boolean isReg;
	int diags;
	double largestDiag;
	
	public Polygon(int[][] v) {
		vertex=new int[v.length][v[0].length];
		for(int i=0;i<v.length;i++) {
			for(int j=0;j<v[0].length;j++) {
				vertex[i][j]=v[i][j];
			}
		}
		numSides=findSides();
		perimeter=findPerimeter();
		area=findArea();
		centroid=new double[2];
		findCentroid();
		isReg=isRegular();
		diags=amountDiagonals();
		largestDiag=findLargestDiag();
	}
	/**
	 * Pre: Private
	 * @return the amount of sides
	 */
	private int findSides() {
		return vertex.length;
	}
	/**
	 * Pre: Public
	 * @return the amount of sides
	 */
	public int getSides() {
		return numSides;
	}
	/**
	 * Pre: Private
	 * @return the perimeter of the shape
	 */
	private double findPerimeter() {
		double temp=0;
		for(int i=0;i<numSides;i++) {
			temp+=findDistance(i,"vertex");
		}
		return temp;
	}
	/**
	 * Pre: private,
	 * @param i index of one end of the diagonal
	 * @param declaration String saying whether checking versus next point, diagonal, or centroid
	 * @return
	 */
	private double findDistance(int i,String declaration) {
		if(declaration.equals("vertex"))
			return Math.sqrt(Math.pow(vertex[(i+1)%numSides][0]-vertex[i%numSides][0], 2)+Math.pow(vertex[(i+1)%numSides][1]-vertex[i%numSides][1], 2));
		else if(declaration.equals("diag"))
			return Math.sqrt(Math.pow(vertex[(i+2)%numSides][0]-vertex[i%numSides][0], 2)+Math.pow(vertex[(i+2)%numSides][1]-vertex[i%numSides][1], 2));
		else
			return Math.sqrt(Math.pow(vertex[(i+1)%numSides][0]-centroid[0], 2)+Math.pow(vertex[(i+1)%numSides][1]-centroid[1], 2));
	}
	/**
	 * Pre: public
	 * @return the perimeter
	 */
	public double getPerimeter() {
		return perimeter;
	}
	/**
	 * Pre: Private
	 * @return the area of the shape
	 */
	private double findArea() {
		double temp=0;
		for(int i=numSides-1;i>=0;i--) {
			temp+=vertex[(i+1)%numSides][0]*vertex[i][1];
		}
		for(int i=numSides-1;i>=0;i--) {
			temp-=vertex[(i+1)%numSides][1]*vertex[i][0];
		}
		temp=Math.abs(temp);
		temp*=0.5;
		return temp;
	}
	/**
	 * Pre: public
	 * @return the area of the shape
	 */
	public double getArea() {
		return area;
	}
	/**
	 * Pre: private
	 * Post: centroid array is filled with X and Y in [0][1[
	 */
	private void findCentroid() {
		double x=0;
		double y=0;
		for(int i=0;i<numSides;i++){
			x+=vertex[i][0];
			y+=vertex[i][1];
		}
		x/=numSides;
		y/=numSides;
		centroid[0]=x;
		centroid[1]=y;
	}
	/**
	 * Pre: public
	 * @return the X position of the centroid
	 */
	public double getCentroidX() {
		return centroid[0];
	}
	/**
	 * Pre: public
	 * @return the Y position of the centroid
	 */
	public double getCentroidY() {
		return centroid[1];
	}
	/**
	 * Pre: private
	 * @return boolean saying if shape is or isn't regular
	 */
	private boolean isRegular() {
		boolean temp=true;
		for(int i=0;i<numSides;i++) {
			if(findDistance(i,"centroid")!=findDistance(1+i,"centroid")) 
				temp=false;
			if(findDistance(i,"vertex")!=findDistance((1+i),"vertex"))
				temp=false;
		}
		return temp;
	}
	/**
	 * Pre: public
	 * @return boolean saying if shape is or isn't regular
	 */
	public boolean getReg() {
		return isReg;
	}
	/**
	 * Pre: private
	 * @return the amount of diagonals
	 */
	private int amountDiagonals() {
		int temp=0;
		temp=numSides*(numSides-3)/2;
		return temp;
	}
	/**
	 * Pre: public
	 * @return the amount of diagonals
	 */
	public int getDiags() {
		return diags;
	}
	/**
	 * Pre: private
	 * @return the length of the largest diagonal
	 */
	private double findLargestDiag() {
		double largest=0;
		for(int i=0;i<numSides;i++) {
			if(findDistance(i,"diag")>largest)
				largest=findDistance(i,"diag");
		}
		return largest;
	}
	/**
	 * Pre: public
	 * @return the length of the largest diagonal
	 */
	public double getLargestDiag() {
		return largestDiag;
	}
}
