import java.util.ArrayList;

public class Driver {
	
	public static void main (String[] args) {
		int[][] v=new int[3][2];
		v[0][0]=0;
		v[0][1]=0;
		v[1][0]=3;
		v[1][1]=0;
		v[2][0]=0;
		v[2][1]=4;
		Polygon vertex=new Polygon(v);
		v[0][0]=-4;
		v[0][1]=0;
		v[1][0]=4;
		v[1][1]=0;
		v[2][0]=0;
		v[2][1]=4;
		Polygon vertex2=new Polygon(v);
		v[0][0]=0;
		v[0][1]=0;
		v[1][0]=3;
		v[1][1]=3;
		v[2][0]=4;
		v[2][1]=2;
		Polygon vertex3=new Polygon(v);
		ArrayList<Polygon> polygons=new ArrayList<Polygon>();
		polygons.add(vertex);
		polygons.add(vertex2);
		polygons.add(vertex3);
		sortPolygons(polygons);
		for(Polygon tri:polygons) {
			int sides=tri.getSides();
			double perimeter=tri.getPerimeter();
			double area=tri.getArea();
			double[] centroid=new double[2];
			centroid[0]=tri.getCentroidX();
			centroid[1]=tri.getCentroidY();
			boolean isRegular=tri.getReg();
			int diagonals=tri.getDiags();
			double largestDiag=tri.getLargestDiag();
			outputs(sides,perimeter,area, centroid, isRegular, diagonals, largestDiag);
		}
	}
	
	public static void sortPolygons(ArrayList<Polygon> list) {
		for(int i=0;i<list.size()-1;i++) {
			if(list.get(i).getArea()>list.get(i+1).getArea()) {
				list.add(i, list.remove(i+1));
				i=-1;
			}
		}
	}
	
	/**
	 * Pre:
	 * @param sides the amount of sides
	 * @param perimeter the perimeter of the shape
	 * @param area the area of the shape
	 * @param centroid the centroid of the shape
	 * @param isRegular boolean if the shape is regular
	 * @param diagonals the amount of diagonals in the shape
	 * @param largestDiag the length of the largest diagonal
	 * Post:
	 * All are printed in an orderly fashion
	 */

	private static void outputs(int sides, double perimeter, double area, double[] centroid, boolean isRegular, int diagonals, double largestDiag) {
		System.out.println("There are " + sides + " sides");
		System.out.println("The perimeter is " + perimeter);
		System.out.println("The area is " + area);
		System.out.println("The centroid is at " + centroid[0] + ", " + centroid[1]);
		if(isRegular)
			System.out.println("This shape is regular");
		else
			System.out.println("This shape is not regular");
		System.out.println("There are " + diagonals + " diagonals");
		if(diagonals!=0)
			System.out.println("The largest diagonal is " + largestDiag);
		System.out.println();
	}
}