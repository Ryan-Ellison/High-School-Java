public class FizzBuzzAgain {
	public static void main(String[] args) {
		int i=1;
		while(i<101) {
			if(i%3==0) 
				System.out.print("fizz");
			if(i%5==0) 
				System.out.print("buzz");
			if(!((i%3==0)||(i%5==0)))
				System.out.print(i);
			System.out.println();
			i++;
		}
	}
}
