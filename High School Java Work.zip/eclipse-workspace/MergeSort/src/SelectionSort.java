import java.util.Arrays;
import java.util.Collections;
public class SelectionSort {

	public static void main(String[] args) {
		int[] arr={8,7,3,2,4,5};
		//look into array initialization lists
		int[] arr1=new int[6];
		int[] arr2=new int[6];
		for(int i=0;i<arr.length;i++) {
			arr1[i]=arr[i];
			arr2[i]=arr[i];
		}
		bubbleSort(arr);
		System.out.println("bubble sorted: ");
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
		selectSort(arr1);		
		System.out.println("select sorted: ");
		for(int i=0;i<arr1.length;i++) {
			System.out.println(arr1[i]);
		}		
		insertSort(arr2);
		System.out.println("insertion sorted: ");
		for(int i=0;i<arr2.length;i++) {
			System.out.println(arr2[i]);
		}
	}


	static void bubbleSort(int[] arr) {
		boolean sorted=false;
		while(!sorted) {
			sorted=true;
			for(int i=0;i<arr.length-1;i++) {
				if(arr[i]>arr[i+1]) {
					swap(arr,i);
					sorted=false;
				}
			}
		}
		
	}

	static void selectSort(int[] arr) {
		boolean sorted=false;
		int min;
		int counter=0;
		int temp=0;
		int hold;
		while(!sorted) {
			sorted=true;
			min = arr[counter];
			for(int i=counter;i<arr.length;i++) {
				if(arr[i]<min) {
					min=arr[i];
					temp=i;
					sorted=false;
				}
			}
			hold=min;
			insert(arr,hold,temp,counter);
			counter++;
		}
	}
	//default to public or private?
	static void insertSort(int[] arr) {
		int[] holder=new int[arr.length];
		for(int i=0;i<holder.length;i++) {
			holder[i]=0;
		}
		for(int i=0;i<arr.length;i++) {
			decide(arr[i],holder,i);
		}
		for(int i=0;i<arr.length;i++) {
			arr[i]=holder[i];
		}
	}
	
	static void insert(int[] arr, int hold,int pos,int counter) {
		for(int i=pos;i>counter;i--) {
			arr[i]=arr[i-1];
		}
		arr[counter]=hold;
	}

	static void swap(int[] arr, int i) {
		int temp=arr[i];
		arr[i]=arr[i+1];
		arr[i+1]=temp;
		
	}

	static void decide(int num, int[] arr,int count) {
		int temp=0;
		while(temp<count) {
			if(num>arr[temp]) {
				temp++;
			}
			else
				break;
		}
		for(int i=arr.length-1;i>temp;i--) {
			arr[i]=arr[i-1];
		}
		arr[temp]=num;
	}
}