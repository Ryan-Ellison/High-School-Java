
public class TopDown {

	public static void main(String[] args) {
		int[] a = new int[5];
		a[0]=2;
		a[1]=4;
		a[2]=7;
		a[3]=3;
		a[4]=1;
		//a[5]=5;
		int[] b= new int[a.length];
		TopDownMergeSort(a,b,a.length);
		System.out.println("Sorted array: ");
		for(int i=0;i<a.length;i++) {
			System.out.println(a[i]);
		}

	}
	
	static void TopDownMergeSort(int[] a,int[] b,int n) {
		CopyArray(a,0,n,b);
		TopDownSplitMerge(b,0,n,a);
	}

	static void TopDownSplitMerge(int[] b, int iBegin, int iEnd, int[] a) {
		if((iEnd-iBegin)<2)
			return;
		int iMiddle=(iEnd+iBegin)/2;
		TopDownSplitMerge(a,iBegin,iMiddle,b);
		TopDownSplitMerge(a,iMiddle,iEnd,b);
		TopDownMerge(b,iBegin,iMiddle,iEnd,a);
		
	}

	 static void TopDownMerge(int[] a, int iBegin, int iMiddle, int iEnd, int[] b) {
		int i=iBegin;
		int j=iMiddle;
		for(int k=iBegin;k<iEnd;k++) {
			if(i<iMiddle && (j>=iEnd|| a[i]<=a[j])) {
				b[k]=a[i];
				i++;
			}
			else {
				b[k]=a[j];
				j++;
			}
			System.out.println(b[k]);
		}
	}

	private static void CopyArray(int[] a, int iBegin, int iEnd, int[] b) {
		for(int i=iBegin;i<iEnd;i++) {
			b[i]=a[i];
		}
		
	}

}
