import java.util.Scanner;

/**
 * ideas:
 * first check if its possible (method exists)
 * Use recursion
 * Herons Formula
 * Change letters where it matches to a number
 */
public class Chaining {
	static String one;
	static String two;
	static String three;
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		one=sc.nextLine();
		two=sc.nextLine();
		three=sc.nextLine();
		String oldOne=one;
		String oldTwo=two;
		String oldThree=three;
		boolean exists=exist(0);
		if(!exists) {
			reset(oldOne,oldTwo,oldThree);
			exists=exist(1);
		}
		if(exists) {
			outputs(oldOne,oldTwo,oldThree);
		}
		else{
			System.out.println("*sad trombone sound*");
		}
		
			
	}
	
	private static void reset(String oldOne, String oldTwo, String oldThree) {
		one=oldOne;
		two=oldTwo;
		three=oldThree;
	}
	

	private static void outputs(String oldOne, String oldTwo, String oldThree) {
		System.out.println("this is one:"+one);
		System.out.println("this is two:"+two);
		System.out.println("this is three:"+three);
		System.out.println("the first vertex is the letter: "+oldOne.charAt(one.indexOf("5")));
		System.out.println("This is at the coordinates: ("+ one.indexOf("5")+","+two.indexOf("5")+")");
		System.out.println("the second vertex is the letter: "+oldThree.charAt(three.indexOf("6")));
		System.out.println("This is at the coordinates: ("+ one.indexOf("6")+","+three.indexOf("6")+")");
		System.out.println("the third vertex is the letter: "+oldTwo.charAt(two.indexOf("7")));
		System.out.println("This is at the coordinates: ("+ two.indexOf("7")+","+three.indexOf("7")+")");
		
	}


	private static boolean exist(int count) {
		boolean oneTwo=false;
		boolean oneThree=false;
		boolean twoThree=false;
		if(count==0) {
			for(int i=0;i<one.length();i++) {
				for(int j=0;j<two.length();j++) {
					if(one.substring(i, i+1).equalsIgnoreCase(two.substring(j, j+1))&&!oneTwo) {
						oneTwo=true;
						one=one.substring(0,i)+"5"+one.substring(i+1);
						two=two.substring(0,j)+"5"+two.substring(j+1);
					}
				}
			}
			for(int i=0;i<one.length();i++) {
				for(int j=0;j<three.length();j++) {
					if(one.substring(i, i+1).equalsIgnoreCase(three.substring(j, j+1))&&!oneThree) {
						oneThree=true;
						one=one.substring(0,i)+"6"+one.substring(i+1);
						three=three.substring(0,j)+"6"+three.substring(j+1);
					}
				}
			}
		}
		else if (count==1){
			for(int i=0;i<one.length();i++) {
				for(int j=0;j<three.length();j++) {
					if(one.substring(i, i+1).equalsIgnoreCase(three.substring(j, j+1))&&!oneThree) {
						oneThree=true;
						one=one.substring(0,i)+"6"+one.substring(i+1);
						three=three.substring(0,j)+"6"+three.substring(j+1);
					}
				}
			}
			for(int i=0;i<one.length();i++) {
				for(int j=0;j<two.length();j++) {
					if(one.substring(i, i+1).equalsIgnoreCase(two.substring(j, j+1))&&!oneTwo) {
						oneTwo=true;
						one=one.substring(0,i)+"5"+one.substring(i+1);
						two=two.substring(0,j)+"5"+two.substring(j+1);
					}
				}
			}
		}
		for(int i=0;i<two.length();i++) {
			for(int j=0;j<three.length();j++) {
				if(two.substring(i,i+1).equalsIgnoreCase(three.substring(j,j+1))&&!twoThree) {
					twoThree=true;
					two=two.substring(0,i)+"7"+two.substring(i+1);
					three=three.substring(0,j)+"7"+three.substring(j+1);
				}
			}
		}
		System.out.println(one+two+three);
		if(three.indexOf("7")<three.indexOf("6")||two.indexOf("7")<two.indexOf("5")){
			return false;
		}
		return(oneTwo&&oneThree&&twoThree);
	}

}
