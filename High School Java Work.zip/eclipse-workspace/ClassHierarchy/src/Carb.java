
public class Carb extends Food{//extends Food makes it a child of Food
	private boolean simple;
	
	public Carb(boolean s, double m) {
		super(m,9*m);//parameters declare which food constructor is run
		System.out.println("Carb constructor");
		simple=s;
	}
	
	public void printFacts() {
		System.out.println("Simple?" + simple);
		super.printFacts();
	}
}
