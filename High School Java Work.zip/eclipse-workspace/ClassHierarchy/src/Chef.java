
public class Chef {
	public static void main (String[] args) {
	//	Food mush=new Food();
	//	Food stuff=new Food(1,34);
		Carb candyCorn=new Carb(true,5);
		Protein chicken=new Protein(false,8);
		Fat gravy=new Fat(true,30);
	//	mush.printFacts();
	//	candyCorn.printFacts();//child overrides parent when two classes have same name and parameters for a class
		chicken.printFacts();
		gravy.printFacts(); 
	}
}
