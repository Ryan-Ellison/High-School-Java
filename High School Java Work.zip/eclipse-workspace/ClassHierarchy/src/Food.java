
public class Food {
	private double mass;
	private double calories;
	
	public Food() {
		System.out.println("Defalt food constructor");
		mass=0;
		calories=-99;
	}
	
	public Food(double m, double cal) {
		System.out.println("Overload constructor");
		mass=m;
		calories=cal;
	}
	
	public void printFacts() {
		System.out.println("This food has");
		System.out.println(mass + " mass");
		System.out.println(calories + " calories");
	}
}
