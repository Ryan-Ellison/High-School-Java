
public class Fat extends Food{
	
	private boolean good;
	
		public Fat(boolean g, double m) {
			super(m,4*m);
			System.out.println("Fat Constructor");
			good = g;
		}
		
		public void printFacts() {
			System.out.println("Good fat?" + good);
			super.printFacts();
		}

}
