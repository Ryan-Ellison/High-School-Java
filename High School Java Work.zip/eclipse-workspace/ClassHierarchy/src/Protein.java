
public class Protein extends Food{
	
	private boolean red;
	
	public Protein(boolean g, double m) {
		super(m,4*m);
		System.out.println("Protein Constructor");
		red = g;
	}
	
	public void printFacts() {
		System.out.println("Red protein?" + red);
		super.printFacts();
	}


}
