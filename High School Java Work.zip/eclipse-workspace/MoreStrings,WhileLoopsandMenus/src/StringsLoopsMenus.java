import java.util.Scanner;
import java.util.*;

public class StringsLoopsMenus {

	public static void main(String[] args) {
		System.out.println("Enter a string.");
		String print="";
		Scanner String = new Scanner(System.in);
		String string=String.next();
		string = string.toLowerCase();
		int inp=-99;
		String menu=Menu();
		while(inp!=6) {
			System.out.println(menu);
			Scanner in = new Scanner(System.in);
			inp=in.nextInt();
			switch (inp) {
				case 1: print=(printStr(string));
					break;
				case 2: print=(printASCIIStr(string));
					break;
				case 3: print=(printReverse(string));
					break;
				case 4: print=(printVowels(string));
					break;
				case 5: print=(printVertical(string));
					break;
				case 6: print=("You have exited the program");
					break;
				default: print=("");
					break;
			}
			System.out.println(print);
		}//end while loop

	}//end main
	
	public static String Menu() {
		return ("Pick a number 1-6" + "\n" + "1: Print String" + "\n" + "2: Print ASCII String" + "\n" + "3: Print Reverse" + "\n" + "4: Print Vowels" + "\n" + "5: Print Vertical" + "\n" + "6: Exit Program");
	}
	
	public static String printStr(String string) {
		return(string);
	}//end printStr
	
	public static String printASCIIStr(String string) {
		String end = "";
		for(int i=0;i<string.length();i++) {
			end += ((int)string.charAt(i));
			if (i<string.length()-1)
				end += "-";
		}//end for loop
		return end;
	}//end printASCIIStr
	
	public static String printReverse(String string) {
		String end = "";
		for(int i=string.length();i>0;i--) {
			end += string.charAt(i-1);
		}//end for loop
		return end;
	}// end printReverse
	
	public static String printVowels(String string) {
		String end = "";
		for(int i=0;i<string.length();i++) {
			if (string.charAt(i)==('a') || string.charAt(i)==('e') || string.charAt(i)==('i') || string.charAt(i)==('o') || string.charAt(i)==('u')){
				end += string.charAt(i);
			}//end if statement
		}//end for loop
		return end;
	}//end printVowels
	
	public static String printVertical(String string) {
		String end = "";
		for (int i=0; i<string.length();i++) {
			end += string.charAt(i)+"\n";
		}
		return end;
	}
}//end class
