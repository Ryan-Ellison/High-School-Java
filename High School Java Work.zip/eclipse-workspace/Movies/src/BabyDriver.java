/**
 * My top 10 movies
 * Zohan
 * Billy Madison
 * Kung Fu Panda
 * Kung Fu Panda 3
 * Spooderman into the Spooderverse
 * The Disaster Artist
 * Baby Driver
 * Anchorman
 * The Incredibles
 * Meet the Robinsons
 */

import java.util.Scanner;
public class BabyDriver {
	static Movie[] movies=new Movie[10];

	public static void main(String[] args) {
		fillMovies();
		System.out.println("Select an option to sort by: 0: Tometer, 1: Audience, 2: Length, 3: Release Date, 4: Domestic, 5: Foreign, 6: Name" );
		Scanner opt=new Scanner(System.in);
		int option=opt.nextInt();
	
		if(option==6) // 6 is name
			nameSort();
		else if(option>=0&&option<=5&&option==(int)option) //an option other than 6 that is valid
			sort(option);
		else //invalid option
			System.out.println("Please restart and use a valid method"); 
	}

	private static void fillMovies() {
		movies[0]=new Movie("Kung Fu Panda",87,82,95,20080606,215434591,416309969);
		movies[1]=new Movie("Kung Fu Panda 3", 86,78,95,20160129,143528619,377642206);
		movies[2]=new Movie("Zohan",37,45,113,20080606,100018837,99917174);
		movies[3]=new Movie("Billy Madison",45,79,90,19950210,25588734,900000);
		movies[4]=new Movie("Spider-Man: Into the Spider-Verse",97,94,116,20181214,169400830,169100000);
		movies[5]=new Movie("The Disaster Artist", 91,86,104,20171201,21120616,8700000);
		movies[6]=new Movie("Baby Driver",93,96,113,20170628,107825862,119119225);
		movies[7]=new Movie("Anchorman - The Legend of Ron Burgundy",66,86,104,20040609,85288303,5285885);
		movies[8]=new Movie("The Incredibles",97,75,116,20041105,261441092,371578642);
		movies[9]=new Movie("Meet the Robinsons",67,74,102,20070330,97822171,71510863);
	}

	private static void sort(int option) {
		boolean sorted=false;
		while(!sorted) {
			sorted=true;
			for(int i=0;i<movies.length-1;i++) {
				if(movies[i].accessor(option)<movies[i+1].accessor(option)) {
					swap(movies,i);
					sorted=false;
				}
			}
		}
		outputs(option);
	}

	private static void outputs(int option) {
		if(option!=3) {
			for(int i=0;i<movies.length;i++) {
				System.out.println(movies[i].accessor(option)+" "+movies[i].getName());
			}
		}
		else {
			for(int i=0;i<movies.length;i++) {
				System.out.println((movies[i].accessor(option)/100)%100+"/"+movies[i].accessor(option)%100+"/"+movies[i].accessor(option)/10000+" "+movies[i].getName());
			}
		}
	}

	static void swap(Movie[] arr, int i) {
		Movie temp=arr[i];
		arr[i]=arr[i+1];
		arr[i+1]=temp;
		
	}

	public static void nameSort() {
		boolean sorted=false;
		while(!sorted) {
			sorted=true;
			for(int i=0;i<movies.length-1;i++) {
				if(movies[i].getName().compareTo(((movies[i+1].getName())))>0) {
					swap(movies,i);
					sorted=false;
				}
			}
		}
		for(int i=0;i<movies.length;i++) {
			System.out.println(movies[i].getName());
		}
	}
}
