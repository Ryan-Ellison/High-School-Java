
public class Movie {
	
	private String name;
	private int tometer;
	private int audience;
	private int length;
	private int date;
	private int domestic;
	private int foreign;
	
	public Movie(String n,int tomatometer,int audienceRate,int runtime,int release,int domesticIncome,int foreignIncome) {
		name=n;
		tometer=tomatometer;
		audience=audienceRate;
		length=runtime;
		date=release;
		domestic=domesticIncome;
		foreign=foreignIncome;
	}
	
	public String getName() {
		return name;
	}
	
	public int accessor(int n) {
		if(n==0)
			return tometer;
		else if(n==1)
			return audience;
		else if(n==2)
			return length;
		else if(n==3)
			return date;
		else if(n==4)
			return domestic;
		else if(n==5)
			return foreign;
		else
			return 0;
	}
}
