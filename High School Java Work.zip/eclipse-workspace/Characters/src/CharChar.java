import java.util.Scanner;

public class CharChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		int a=in.nextInt();
		in.close();
		if(a>=0&&a<=127) {
			System.out.println(a + " in character form = " + (char) a);
			if (typeChecker(a)==1)
				System.out.println("You have a letter");
			else if (typeChecker(a)==2)
				System.out.println("You have a number");
			else
				System.out.println("You don't have a number or a letter!");
			beforeAndAfter(a);
			capitalSwap(a);
		}
		else
			System.out.println("enter a number 0-127");
	}
	
	public static int typeChecker(int a) {
		if ((65<=a && a<=90) || (97<=a && a<=122))
			return 1;
		else if (48<=a && a<=57)
			return 2;
		else
			return 0;
	}//end type checker
	
	public static void beforeAndAfter(int a) {
		System.out.println("The char before is: " + ((char) (a-1)));
		System.out.println("The char after is: " + ((char) (a+1)));
	}//end beforeAndAfter
	
	public static void capitalSwap(int a) {
		if (typeChecker(a)==1) {
			if (65 <= a && a<=90)
				System.out.println("The lowercase version of this character is: " + (char) (a+32));
			else
				System.out.println("The uppercase version of this character is: " + (char) (a-32));
				
		}
	}

}
