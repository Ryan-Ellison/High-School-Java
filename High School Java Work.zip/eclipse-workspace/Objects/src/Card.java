
public class Card {
//instance variables are private, only accessed by an object of the Card class (this class)
	private int rank;
	private String suit;
	
	//Overloading is when you have two methods with the same name and different parameter lists
	//method is the constructor method
	
	/**
	 * A constructor method for the cards
	 */
	
	public Card() {
		rank=(int)(Math.random()*13);//0-12 inclusive
		int temp=(int)(Math.random()*4);
		switch(temp) {
			case 0:suit="Clubs";
			break;
			case 1:suit="Spades";
			break;
			case 2:suit="Diamonds";
			break;
			case 3:suit="Hearts";
			break;
		}
		accessor();
	}
	
	/**
	 * Pre:
	 * @param temp: an int saying what suit this hand will be
	 * @param declaration: a String stating that this method is for the flush hand
	 * Post:the cards will form a flush
	 */
	
	public Card(int temp, String declaration) {
		rank=(int)(Math.random()*13);//0-12 inclusive
		switch(temp) {
			case 0:suit="Clubs";
			break;
			case 1:suit="Spades";
			break;
			case 2:suit="Diamonds";
			break;
			case 3:suit="Hearts";
			break;
		}
		accessor();
	}
	
	/**
	 * Pre:
	 * @param straightRank: an int stating the rank of the card, to make a straight
	 * Post:
	 * The cards will form a straight
	 */
	
	public Card(int straightRank) {
		rank=straightRank;
		int temp=(int)(Math.random()*4);
		switch(temp) {
		case 0:suit="Clubs";
		break;
		case 1:suit="Spades";
		break;
		case 2:suit="Diamonds";
		break;
		case 3:suit="Hearts";
		break;
		}
	}
	
	/**
	 * Print the card's rank and suit
	 */
	
	public void printCard() {
		System.out.print(convertRank());
		System.out.println(" of "+suit);
	}
	
	/**
	 * Pre:
	 * the rank of the card
	 * Post:
	 * @return the rank converted to a string with face values assigned
	 */
	
	private String convertRank() {
		switch(rank) {
			case 8: return "10";
			case 9: return "J";
			case 10: return "Q";
			case 11: return "K";
			case 12: return "A";
			default: return (char)(rank+(int)('2'))+"";
		}
	}
	
	/**
	 * @return a combination of the rank and suit
	 */
	
	public String accessor() {
		String temp;
		temp=convertRank()+suit;
		return temp;
	}
	
	/**
	 * @return a string of the card's suit
	 */
	
	public String getSuit() {
		return(suit);
	}
	
	/**
	 * @return an int saying the card's true rank
	 */
	
	public int getRank() {
		return rank;
	}
	
	
	
	
	
}
