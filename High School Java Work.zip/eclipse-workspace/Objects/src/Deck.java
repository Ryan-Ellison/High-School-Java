import java.util.Arrays;

public class Deck {

	public static void main(String[] args) {
		Card[] hand=new Card[5];
		assignHand(hand);
		//assignStraight(hand);
		//assignFlush(hand);
		for(int i=0;i<hand.length;i++) {
			hand[i].printCard();
		}
		System.out.println();
		sortHand(hand);
		int pairs=numPairs(hand);
		int triples=numTriples(hand);
		int quads=numQuads(hand);
		boolean flush=gotFlush(hand);
		boolean straight=gotStraight(hand);
		outputs(hand,pairs,triples,quads,flush,straight);
	}
	
	/**
	 * Pre:
	 * @param h: a 1D card array 
	 * Post:
	 * the 1D card array is filled with unique cards that form a flush
	 */
	
	public static void assignFlush(Card[] h) {
		int suit=(int)(Math.random()*4);
		for(int i=0;i<h.length;i++) {
			h[i]=new Card(suit,"Suit");
			for(int j=0;j<i;j++) {
				if(sameCard(h[i],h[j])) {
					i--;
					j=i;
				}
			}
		}
	}
	
	/**
	 * Pre:
	 * @param h: a 1D card array
	 * Post:
	 * the 1D card array is filled with unique cards that form a straight
	 */
	
	public static void assignStraight(Card[] h) {
		int minRank=(int)(Math.random()*9);
		int temp=0;
		int[] ranks=new int[h.length];
		while(temp<h.length){
			ranks[temp]=(int) (Math.random()*5)+minRank;
			for(int i=0;i<temp;i++) {
				if(ranks[temp]==ranks[i]) {
					temp--;
					i=temp;
				}
			}
			temp++;
		}
		for(int i=0;i<h.length;i++) {
			h[i]=new Card(ranks[i]);
		}
	}
	
	/**
	 * Pre:
	 * @param h:a 1D card array
	 * Post:
	 * the 1D card array is filled with random unique cards
	 */
	
	public static void assignHand(Card[] h) {
		for(int i=0;i<h.length;i++) {
			h[i]=new Card();
			for(int j=0;j<i;j++) {
				if(sameCard(h[i],h[j])) {
					i--;
					j=i;
				}
			}
		}
	}
	
	/**
	 * Pre:
	 * @param h: a 1D card array
	 * Post:
	 * @return an int representing the amount of pairs in this hand, not counting triples or quads
	 */
	
	public static int numPairs(Card[] h) {
		boolean pair=false;
		int xyz=0;
		boolean check=true;
		for(int i=0;i<h.length;i++) {
			pair=false;
			check=true;
			for(int j=i+1;j<h.length;j++) {
				if(!pair&&check) {
					if(sameRank(h[i],h[j])) {
						pair=true;
					}
				}
				else if(pair&&check){
					if(sameRank(h[i],h[j])) {
						pair=false;
						check=false;
					}
				}
			}
			if(pair)
				xyz++;
			if(!check){
				xyz--;
			}
		}
		if(xyz<0)
			xyz=0;
		return xyz;
	}

	/**
	 * Pre:
	 * @param h:a 1D card array
	 * Post:
	 * @return an int representing the amount of quads in this hand, not counting pairs or triples
	 */
	
	public static int numQuads(Card[] h) {
		boolean triple=false;
		int xyz=0;
		boolean check=true;
		int temp=0;
		for(int i=0;i<h.length;i++) {
			temp=0;
			triple=false;
			check=true;
			for(int j=i+1;j<h.length;j++) {
				if(!triple&&check) {
					if(sameRank(h[i],h[j])) {
						temp++;
					}
				}
				else if(triple&&check){
					if(sameRank(h[i],h[j])) {
						triple=false;
						check=false;
					}
				}
				if(temp==3) {
					triple=true;
				}
			}
			if(triple)
				xyz++;
			if(!check){
				xyz-=2;
			}
		}
		if(xyz<0)
			xyz=0;
		return xyz;
	}
	
	/**
	 * Pre:
	 * @param h: a 1D card array
	 * Post:
	 * @return an int representing the amount of triples in this hand, not including pairs or quads
	 */
	
	public static int numTriples(Card[] h) {
		boolean triple=false;
		int xyz=0;
		boolean check=true;
		int temp=0;
		for(int i=0;i<h.length;i++) {
			temp=0;
			triple=false;
			check=true;
			for(int j=i+1;j<h.length;j++) {
				if(!triple&&check) {
					if(sameRank(h[i],h[j])) {
						temp++;
					}
				}
				else if(triple&&check){
					if(sameRank(h[i],h[j])) {
						triple=false;
						check=false;
					}
				}
				if(temp==2) {
					triple=true;
				}
			}
			if(triple)
				xyz++;
			if(!check){
				xyz-=2;
			}
		}
		if(xyz<0)
			xyz=0;
		return xyz;
	}

	/**
	 * Pre:
	 * @param h:a 1D card array
	 * Post:
	 * @return a boolean representing true or false depending on if you got a flush or not
	 */
	
	public static boolean gotFlush(Card[] h) {
		boolean temp=true;
		for(int i=0;i<h.length-1;i++) {
			if(!h[i].getSuit().equals(h[i+1].getSuit()))
				temp=false;
		}
		return temp;
	}
	
	/**
	 * Pre:
	 * @param h: a 1D card array
	 * Post:
	 * @return the highest ranked card from the 1D array
	 */
	
	public static Card findHighest(Card[] h) {
		int temp=0;
		Card highest = null;
		for(int i=0;i<h.length;i++) {
			if(temp<h[i].getRank()) {
				temp=h[i].getRank();
				highest=h[i];
			}
			
		}
		return highest;
	}

	/**
	 * Pre:
	 * @param h: a 1D card array
	 * Post:
	 * The 1d array is sorted by rank from lowest to highest
	 */
	
	public static void sortHand(Card[] h) {
		Card[] temp=new Card[5];
		int[] ranks=new int[5];
		for(int i=0;i<ranks.length;i++) {
			ranks[i]=h[i].getRank();
		}
		Arrays.sort(ranks);
		for(int i=0;i<h.length;i++) {
			for(int j=0;j<h.length;j++) {
				if(ranks[i]==h[j].getRank()) {
					temp[i]=h[j];
					h[j]=new Card(14);
					break;
				}
			}
		}
		for(int i=0;i<h.length;i++) {
			h[i]=temp[i];
		}
	}
	
	/**
	 * Pre:
	 * @param h:a 1D card array
	 * Post:
	 * @return a boolean stating true or false depending on if you got a straight or not
	 */
	
	public static boolean gotStraight(Card[] h) {
		boolean temp=true;
		int counter=0;
		for(int i=0;i<h.length-1;i++) {
			if((h[i].getRank())==(h[i+1].getRank()-1)) {
				counter++;
			}
		}
		if(counter!=4||gotFlush(h))
			temp=false;
		return temp;
	}
	
	/**
	 * Pre:
	 * @param c1:a card
	 * @param c2:a card
	 * Post:
	 * @return true if they are the same rank, false if not
	 */
	
	public static boolean sameRank(Card c1, Card c2) {
		return (c1.getRank()==c2.getRank());
	}

	/**
	 * Pre:
	 * @param c1:a card
	 * @param c2:a card
	 * Post:
	 * @return true if they are the same suit, false if not
	 */
	
	public static boolean sameSuit(Card c1, Card c2) {
		return (c1.getSuit().equals(c2.getSuit()));
	}
	
	/**
	 * Pre:
	 * @param c1:a card
	 * @param c2:a card
	 * Post:
	 * @return true if they are the same card, false if not
	 */
	
	public static boolean sameCard(Card c1, Card c2) {
		if(c1.getRank()==(c2.getRank())&&c1.getSuit().equals(c2.getSuit())) 
			return true;
		else
			return false;
		
	}
	
	/**
	 * Pre:
	 * @param h:a 1D card array
	 * @param pairs:an int representing the amount of pairs
	 * @param triples:an int representing the amount of triples
	 * @param quads:an int representing the amount of quads
	 * @param flush:a boolean representing if you got a flush or not
	 * @param straight:a boolean representing if you got a straight or not
	 * Post:
	 * All of these are printed in an organized manner
	 */
	
	public static void outputs(Card[] h, int pairs, int triples, int quads,boolean flush,boolean straight) {
		for(int i=0;i<h.length;i++) {
			h[i].printCard();
		}
		System.out.println("You have "+pairs+" pairs");
		System.out.println("You have "+triples+" triples");
		System.out.println("You have "+quads+" quads");
		if(flush)
			System.out.println("You got a flush!");
		else
			System.out.println("You didn't get a flush!");
		if(straight)
			System.out.println("You got a straight!");
		else
			System.out.println("You didn't get a straight!");
	}
}
