/*
 * Ryan Ellison
 * 2/5/18
 * Program description:
 * Find the summations of various numbers
 */
public class PartI {

	public static void main(String[] args) {
		sumInts(5);
		sumSquares(4);
		sumReciprocals(6);
	}//end main
	
	public static void sumInts(int a) {
		int sum =0;
		for (int i=1;i<=a;i++) {
			partThree(i,i,a,"");		
			sum += i;
		}//end for loop
		System.out.println(sum);
	}//end sumInts
	
	public static void sumSquares(int a){
		int sum=0;
		for (int i=1;i<=a;i++) {
			partThree((int)Math.pow(i, 2),i,a,"");
			sum += (Math.pow(i, 2));
		}//end for loop
		System.out.println(sum);
	}//end sumSquares
	
	public static void sumReciprocals(int a) {
		double sum=0.0;
		for (int i=1;i<=a;i++) {
			partThree(i,i,a, "1/");
			sum += (1.0/i);
		}//end for loop
		System.out.println(sum);
	}//end sumReciprocals
	
	public static void partThree(int i,int b, int a, String c) {//i=printed number, b=loop count, a=amount of times, c=printed string
		if (b<a)
			System.out.print(c + i + " + ");
		else
			System.out.print(c + i + " = ");

	}//end partThree
}//end main
