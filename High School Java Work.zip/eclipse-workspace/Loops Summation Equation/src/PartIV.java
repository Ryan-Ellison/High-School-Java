/*
 * Ryan Ellison
 * 2/7/18
 * Program description:
 * Calculate factorials, combinations, and expand binomial equations
 */
public class PartIV {

	public static void main(String[] args) {
		int n1=5;
		int r1=2;
		int a2=1;//A
		int b2=1;//B
		int n2=3;//the power
		int m2=1;//# of terms (1 or 2)
		System.out.println(factorial(n1));
		System.out.println(chooses(n1,r1));
		expandBinomial(a2,b2,n2,m2);
	}//end main

	public static double factorial(int n) {
		int sum = 1;
		for (int i=1;i<=n;i++) {
			sum *= i;
		}//end for loop
		return sum;
	}//end factorial
	
	public static double chooses(int n, int r) {	
		return factorial(n)/(factorial(n-r)*factorial(r));
	}//end chooses
	
	public static void binomialExpansionTerm(int a,int b,int n,int m, int i/*loop number*/) {
		double partOne=chooses(n,i-1);
		double partTwo=Math.pow(a, n-(i-1));
		double partThree=Math.pow(b,i-1);
		String partFour="";
		String partFive="";
		if (i<n) {
			partFour="X^" + (n-(i-1));
		}
		else if (i==n) {
			partFour="X";
		}
		else {
			partFour="";
		}
		if (m==2) {
			if (i>2)
				partFive="Y^" +(i-1);
			else if (i==2)
				partFive="Y";
			else
				partFive="";
		}
		System.out.print(partOne * partTwo * partThree + " " +  partFour + " " + partFive + "");
}//end binomialExpansionTerm
	
	public static void expandBinomial(int a/*A*/, int b/*B*/, int n/*the exponent*/, int m /*# of terms*/) {
		for (int i=1;i<=n+1;i++) {
			binomialExpansionTerm(a,b,n,m,i);
			if (i<=n) 
				System.out.print(" + ");
		}//end for loop
	}//end expandBinomial
	
}//end class
