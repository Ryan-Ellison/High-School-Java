/*
 * Ryan Ellison
 * 2/7/18
 * Program description:
 * Print even and odd numbers
 */
public class PartV {

	public static void main(String[] args) {
		printEvens();
		printOdds();
	}//end main
	
	public static void printEvens() {
		System.out.print("Evens: ");
		for(int i=0;i<10;i++) {
			if (i<9)
				System.out.print(i*2 + ", " );
			else
				System.out.print(i*2);
		}//end for loop
		System.out.println();
	}//end printEvens
	
	public static void printOdds() {
		System.out.print("Odds: ");
		for(int i=0;i<10;i++) {
			if (i<9)
				System.out.print(i*2+1 + ", ");
			else
				System.out.print(i*2+1);
		}//end for loop
		System.out.println();
	}//end printOdds
}
