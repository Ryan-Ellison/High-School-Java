/*
 * Ryan Ellison
 * 2/5/18
 * Program description:
 * Find the summations of various numbers
 */
public class PartII {

	public static void main(String[] args) {
		methodOne();
		methodTwo();
		methodThree();
		methodThreeA();
		methodFour();
	}//end main
	
	public static void methodOne() {
		int n=6;
		int sum = 0;
		for (int i=1;i<=n;i++) {
			partThree((int)(2*Math.pow(i, 2)-1),i,n,"");
			sum += (2*Math.pow(i, 2)-1);
		}//end for loop
		System.out.println(sum);
	}// end methodOne
	
	public static void methodTwo() {
		int n=12;
		double sum=0;
		for(int i=3;i<=n;i++) {
			partThree((int)(Math.pow(i, 2)),i,n,"3/");
			sum += 3.0/Math.pow(i, 2.0);
		}//end for loop
		System.out.println(sum);
	}//end methodTwo
	
	public static void methodThree() {
		int n=8;
		int sum =0;
		for(int i=1;i<=n;i++) {
			partThree((int)(i*Math.pow(-1, i+1)),i,n,"");
			sum += i*Math.pow(-1.0, i+1);
		}//end for loop
		System.out.println(sum);
	}//end methodThree
	
	public static void methodThreeA() {
		int n=8;
		int sum=0;
		for(int i=1; i<=n; i++) {
			partThree((int)(i*Math.pow(-1, i+1)),i,n,"");
			if (i%2==1)
				sum+=i;
			else
				sum-=i;
		}//end for loop
		System.out.println(sum);
	}//end methodThreeA
	
	public static void methodFour() {
		int n = 5;
		int sum =0;
		for(int i=1;i<=n;i++) {
			partThree(11,i,n,"");
			sum += 11;
		}//end for loop
		System.out.println(sum);
	}//end methodFour
	
	public static void partThree(int i, int b, int a, String c) {
		if (b<a)
			System.out.print(c + i + " + ");
		else
			System.out.print(c + i + " = ");
	}//end partThree
}
