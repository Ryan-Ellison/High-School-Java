import java.util.Scanner;

public class ACSL1 {

	public static void main(String[] args) {
		Scanner number=new Scanner(System.in);
		String num=number.nextLine();
		int n=number.nextInt();
		work(num,n);
	}
	
	/**
	 * 
	 * @param x pos number < 10^50
	 * @param n number that seperates
	 */
	
	public static void work(String x, int n) {
		String number=x+"";
		System.out.println(number);
		int[][] sep;
		int sum=0;
		int count;
		int exp=0;
		while(number.length()%n!=0) {
			number+="0";
		}
		sep=new int[number.length()/n][n];
		for(int i=0;i<sep.length;i++) {
			for(int j=0;j<n;j++) {
				sep[i][j]=Integer.parseInt(number.substring(i*n+j, i*n+j+1));
			}
		}
		for(int i=n-1;i>=0;i--) {
			count=0;
			for(int j=0;j<sep.length;j++) {
				count+=sep[j][i];
			}
			count=(int)Math.pow(10, exp)*count;
			exp++;
			sum+=count;
		}
		System.out.println("sum: "+sum);
		for(int i=0;i<sep.length;i++) {
			for(int j=0;j<sep[0].length;j++) {
				System.out.print(sep[i][j] + " ");
			}
			System.out.println();
		}
	}

}
