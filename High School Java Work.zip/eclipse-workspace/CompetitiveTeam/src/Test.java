import java.util.*;

public class Test {
	public static void main(String[] args) {
		ArrayList<Integer> test = new ArrayList<Integer>();
		test.set(5,69);
		System.out.println(test);
	}

}
