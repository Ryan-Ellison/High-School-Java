
public class ASCL2 {
	public static void main(String[] args) {
		String one="The quick brown fox did jump over a log";
		String two="The brown rabbit quickly did outjump the fox";
		String a=diff(one,two);
		String b=diff(two,one);
		System.out.println("a = "+a);
		System.out.println("b = "+b);
	}

	private static String diff(String one, String two) {
		int i=0;
		String temp="";
		while(i<=one.length()) {
			i=one.indexOf(" ");
			if(i!=-1) {
				if(two.indexOf(one.substring(0, i))!=-1) {
					temp+=one.substring(0,i)+" ";
					two=two.substring(0, two.indexOf(one.substring(0, i)))+two.substring(i+two.indexOf(one.substring(0, i)));
				}
			}
			else{
				if(two.indexOf(one)!=-1) {
					temp+=one;
				}
				return temp;
			}
			one=one.substring(i+1);
		}
		return temp;
	}
}
