package testNull;

public class Object {
	private int num;
	private boolean boo;
	private String string;
	private YObject you;
	
	
	public YObject getYou() {
		return you;
	}
	public void setYou(YObject you) {
		this.you = you;
	}
	
	
	public String getString() {
		System.out.println(string.length());
		return string;
		
	}
	public void setString(String string) {
		this.string = string;
	}
	
	
	public boolean isBoo() {
		return boo;
	}
	public void setBoo(boolean boo) {
		this.boo = boo;
	}
	
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	
	
}
