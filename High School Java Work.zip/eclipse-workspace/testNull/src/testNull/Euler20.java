package testNull;

public class Euler20 {

	public static void main(String[] args) {
		int[] facts= new int[10];
		for(int i=0;i<facts.length;i++) {
			facts[i]=1;
		}
		for(int count = 0; count < facts.length; count++) {
			for(int i=10*count+1;i<=10*(count+1);i++) {
				facts[count]*=i;
			}
			System.out.println(facts[count] + "   " + count + "   " + facts.length);
			while(facts[count]%10==0) {
				facts[count]/=10;
			}
		}
		

	}

}
