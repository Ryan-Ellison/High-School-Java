package testNull;

public class Driver {
	
	public static void main(String[] args) {
		Object obj=new Object();
		System.out.println(obj.getNum()+"    "+obj.getString()+"     "+obj.isBoo()+"     "+obj.getYou());
	}
	
}
