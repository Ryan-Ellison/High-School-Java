package testNull;

public class YObject {

}
