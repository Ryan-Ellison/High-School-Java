import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class GSkeleton extends JFrame implements MouseInputListener{
	
	private Graphics g;
	private int x;
	private int y;
	Color random;
	
	public GSkeleton() {
		super("My First Graphics Window");
		x=400;
		y=400;
		setSize(x,y);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		addMouseMotionListener(this);
		addMouseListener(this);
	}

	
	public void mouseClicked(MouseEvent e) {
		
		
	}

	
	public void mouseEntered(MouseEvent e) {
		
		
	}

	
	public void mouseExited(MouseEvent e) {
		
		
	}

	
	public void mousePressed(MouseEvent e) {
		//System.out.println("mouse pressed at (" + e.getX() + "," + e.getY() + ")");
		
	}

	
	public void mouseReleased(MouseEvent e) {
		
	}

	
	public void mouseDragged(MouseEvent e) {
		//System.out.println("mouse dragged to (" + e.getX() + "," + e.getY() +")");
		g=this.getGraphics();
		random=new Color((int)(Math.random()*256),(int)(Math.random()*256),(int)(Math.random()*256));
		g.setColor(random);
		g.drawLine(x/2, y/2, e.getX()+1, e.getY()+1);
		
	}

	
	public void mouseMoved(MouseEvent e) {
		
		
	}

}
