package compchapterUno;
import java.util.Scanner;

public class qOne {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		double db=sc.nextDouble();
		System.out.printf("%7.3f",db);
		sc.close();
	}

}
