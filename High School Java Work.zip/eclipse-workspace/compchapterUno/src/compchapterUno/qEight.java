package compchapterUno;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class qEight {

	public static void main(String[] args) throws IOException {
		File file=new File("qEight.txt");
		FileWriter writer = new FileWriter(file.getAbsoluteFile());
		int[] set= new int[20];
		for(int i=1;i<=set.length;i++) {
			set[i-1]=i;
		}
		String binary;
		ArrayList<Integer> sub=new ArrayList<Integer>();
		for(int i=0;i<Math.pow(2,set.length);i++) {
			binary=Integer.toBinaryString(i);
			while(binary.length()<set.length) {
				binary="0"+binary;
			}
			for(int k=0;k<binary.length();k++) {
				if(binary.charAt(binary.length()-k-1)=='1')
					sub.add((Integer)set[binary.length()-k-1]);
			}
			writer.write("    {");
			for(int k=0;k<sub.size();k++) {
				writer.write(Integer.toString(sub.get(k)));
				if(k!=sub.size()-1){
					writer.write(",");
				}
			}
			writer.write("}"+'\n');
			sub.clear();
		}
		writer.close();
		
	}

}
