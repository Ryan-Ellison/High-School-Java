package compchapterUno;
import java.util.Scanner;
import javax.script.*;

public class qOnetyOneBook {

	public static void main(String[] args) throws ScriptException {
		
		ScriptEngineManager mgr = new ScriptEngineManager();
		ScriptEngine engine = mgr.getEngineByName("JavaScript");
		Scanner sc = new Scanner(System.in);
		while (sc.hasNextLine()) System.out.println(engine.eval(sc.nextLine()));
		
	}

}
