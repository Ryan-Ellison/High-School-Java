package compchapterUno;
import java.util.Scanner;

public class qTwo {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		int len=sc.nextInt();
		System.out.printf("%1."+len+"f",Math.PI);
		sc.close();

	}

}
