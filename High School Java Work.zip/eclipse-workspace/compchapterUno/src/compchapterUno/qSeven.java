package compchapterUno;
import java.util.ArrayList;


public class qSeven {

	public static void main(String[] args) {
		
		ArrayList<String> alpha = new ArrayList<String>();
		alpha.add("a");
		alpha.add("b");
		alpha.add("c");
		alpha.add("d");
		alpha.add("e");
		alpha.add("f");
		alpha.add("g");
		alpha.add("h");
		alpha.add("i");
		alpha.add("j");
		print(alpha);
	}

	public static void print(ArrayList<String> alpha) {
		int counts=1;
		for(int i=1;i<=alpha.size();i++) {
			counts*=i;
		}
		for(int i=0;i<counts;i++) {
			System.out.println(alpha);
			alpha.add(8,alpha.remove(9));
			if(i%2==0)
				alpha.add(7,alpha.remove(8));
			if(i%6==0)
				alpha.add(6,alpha.remove(7));
			if(i%24==0)
				alpha.add(5,alpha.remove(6));
			if(i%120==0)
				alpha.add(4,alpha.remove(5));
			if(i%720==0)
				alpha.add(3,alpha.remove(4));
			if(i%5040==0)
				alpha.add(2,alpha.remove(3));
			if(i%40320==0)
				alpha.add(1,alpha.remove(2));
			if(i%362880==0)
				alpha.add(0,alpha.remove(1));
		}
	}

}
