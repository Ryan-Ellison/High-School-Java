package compchapterUno;
import java.util.Scanner;

public class qTen {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		String str=sc.nextLine();
		String pattern = "\\b[A-Za-z]\\d{2}\\b";
		System.out.println(str.replaceAll(pattern,"***"));
		sc.close();
		
	}

}
