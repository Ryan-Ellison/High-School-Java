package compchapterUno;
import java.util.Scanner;

public class qNine {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Input first number's base");
		int b1 = sc.nextInt();
		System.out.println("Input first number");
		String num1 = sc.next();
		System.out.println("Input second number's base");
		int b2 = sc.nextInt();
		int halfway;
		if(b1 != 10) 
			halfway = convertTen(num1,b1);
		else
			halfway = Integer.parseInt(num1);
		String fin = convertFromTen(halfway, b2);
		System.out.println(fin);
	}
	
	public static int convertTen(String num, int base) {
		int temp = 0;
		int count = 0;
		for(int i = num.length() - 1; i >= 0; i--) {
			if((int) num.charAt(count) >= 65) {
				temp += ((int) num.charAt(count) - 55)*Math.pow(base,i);
			}
			else {
				temp += ((int) num.charAt(count) - 48)*Math.pow(base,i);
			}
			count++;
		}
		return temp;
	}
	
	public static String convertFromTen(int num, int base) {
		int temp = 0;
		String result = "";
		while(num > 0) {
			temp = num%base;
			if(temp >= 10) {
				result=((char) (temp+55))+result;
			}
			else
				result=temp+result;
			num /= base;
			num = (int) num;
		}
		if (result.equals(""))
			return "0";
		return result;
	}
}
