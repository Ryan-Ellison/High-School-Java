package compchapterUno;
import java.util.Calendar;
import java.util.Scanner;

public class qThree {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("input year");
		int year=sc.nextInt();
		System.out.println("input month");
		int month=sc.nextInt();
		System.out.println("input date");
		int day=sc.nextInt();
		Calendar x=Calendar.getInstance();
		x.set(Calendar.YEAR, year);
		x.set(Calendar.MONTH, month-1);
		x.set(Calendar.DAY_OF_MONTH, day);
		System.out.println(x.getTime());
		sc.close();
		
	}

}
