package compchapterUno;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;

public class qFour {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("How many numbers will you input?");
		int length=sc.nextInt();
		ArrayList<Integer> numbers=new ArrayList<Integer>();
		for(int i=0;i<length;i++) {
			numbers.add(sc.nextInt());
		}
		Collections.sort(numbers);
		for(int i=0;i<numbers.size()-1;i++) {
			if(numbers.get(i)==numbers.get(i+1)) {
				numbers.remove(i);
				i--;
			}
		}
		System.out.println(numbers);
		sc.close();
	}

}