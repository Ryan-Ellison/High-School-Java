package compchapterUno;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Collections;

public class qFive {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		ArrayList<ArrayList<Integer>> people=new ArrayList<ArrayList<Integer>>();
		System.out.println("Enter the amount of people");
		int length=sc.nextInt();
		for(int i=0;i<3;i++) {
			people.add(new ArrayList<Integer>());
		}
		int temp;
		for(int i=0;i<length;i++) {
			for(int j=0;j<3;j++) {
				if(j==0)
					System.out.println("Enter the day");
				else if(j==1)
					System.out.println("Enter the month");
				else
					System.out.println("Enter the year");
				temp=sc.nextInt();
				people.get(j).add((Integer)temp);
			}
		}
		
		System.out.println("sorted by month");
		ArrayList<Integer> month=new ArrayList<Integer>();
		month=people.get(1);
		Collections.sort(month);
		System.out.println(month);
		
		System.out.print("sorted by days");
		ArrayList<Integer> days=new ArrayList<Integer>();
		days=people.get(0);
		Collections.sort(days);
		System.out.println(days);
		
		System.out.println("sorted by age");
		Collections.sort(people.get(2));
		for(int i=0;i<people.get(2).size()-1;i++) {
			if(people.get(2).get(i)==people.get(2).get(i+1)) {
				if(people.get(1).get(i)==people.get(1).get(i+1)) {
					if(people.get(0).get(i)>people.get(0).get(i+1)) {
						people.get(0).add(i,people.get(0).remove(i+1));
						i--;
					}
				}
				else if(people.get(1).get(i)>people.get(1).get(i+1)) {
					people.get(1).add(i,people.get(1).remove(i+1));
					i--;
				}
			}
		}
		for(int i=0;i<people.get(0).size();i++) {
			System.out.println(people.get(2).get(i)+" "+people.get(1).get(i)+" "+people.get(0).get(i));
		}
		
	}

}
