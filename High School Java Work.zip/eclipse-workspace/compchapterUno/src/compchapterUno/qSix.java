package compchapterUno;
import java.util.Scanner;
import java.util.Arrays;

public class qSix {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		int[] numbers=new int[1000000];
		for(int i=0;i<numbers.length;i++) {
			numbers[i]=i;
		}
		Arrays.sort(numbers);
		System.out.println("What number are you looking for?");
		int search=sc.nextInt();
		boolean exist=check(numbers.length/2, search, 20,1,numbers);
		System.out.println(exist);
	}

	public static boolean check(int spot, int search, int max, int count,int[] num) {
		if(count<max) {
			System.out.println(spot+ "   " + (num.length/(Math.pow(2,count)))+"   "+count);
			if(num[spot]==search)
				return true;
			else if(num[spot]>search)
				return(check((int)(spot-(num.length/(Math.pow(2,count+1)))),search,max,count+1,num));
			else if(num[spot]<search)
				return(check((int)(spot+(num.length/(Math.pow(2,count+1)))),search,max,count+1,num));
		}
		return false;
	}

}
