package compchapterUno;
import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class qOnetyOne {

	static Pattern number=Pattern.compile("\\s*\\d+([.]\\d+)?\\s*");
	static Pattern md=Pattern.compile("[*]|[/]");
	static Pattern as=Pattern.compile("[+]|((?<!^)[-])");
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		String equation = sc.nextLine();
		int par1=0;
		int par2=equation.length()-1;
		
		for(int i=0;i<equation.length();i++) {
			if(equation.substring(i,i+1).equals("(")) {
				par1=i;
			}
			if(equation.substring(i,i+1).equals(")")) {
				par2=i;
				equation=equation.substring(0,par1)+solve(equation.substring(par1,par2+1))+equation.substring(par2+1);
				System.out.println(equation);
				i=0;
			}
		}
		
		equation=solve(equation);
		System.out.println(equation);
	
	}

	private static String solve(String equation) {
		
		Matcher multidiv=md.matcher(equation);
		
		while(multidiv.find()) {
			equation=equate(equation,multidiv.group());
			multidiv=md.matcher(equation);
		}
		
		Matcher addsub=as.matcher(equation);
		
		while(addsub.find()) {
			equation=equate(equation,addsub.group());
			addsub=as.matcher(equation);
		}
		
		return equation;
	
	}

	public static String equate(String equation, String matched) {
		
		if(equation.charAt(0)=='(')
			equation=equation.substring(1,equation.length()-1);
		String match="([-])?" + number + "[" + matched + "]" + "\\s*([-])?\\s*" + number;
		Pattern p=Pattern.compile(match);
		Matcher matcher=p.matcher(equation);
	    matcher.find();
		String work=matcher.group();
		
		while(work.charAt(0)==' ') {
			work=work.substring(1);
		}
		
		String num1 = "";
		Pattern dig=Pattern.compile("([-])|\\d|[.]");
		
		while(dig.matcher(work.substring(0,1)).find()) {
			if(num1.length()>0&&work.charAt(0)==('-'))
				break;
			num1+=work.substring(0,1);
			work=work.substring(1);
		}
		
		work=work.replaceFirst("([*]|[/]|[-]|[+])","");
		double num2;
		num2=Double.parseDouble(work);
		double res = 0;
		if(matched.equals("*"))
			res = (Double.parseDouble(num1)*num2);
		else if(matched.equals("/")) 
			res = (Double.parseDouble(num1)/num2);
		else if(matched.equals("+"))
			res = (Double.parseDouble(num1)+num2);
		else if(matched.equals("-")) 
			res = (Double.parseDouble(num1)-num2);
		
		equation=equation.replaceFirst(match,Double.toString(res));
		return equation;
	}

}
//3 + (8 - 7.5 + (5 / -2.5)) * 10 / 5 - (2 + 5 * 7)