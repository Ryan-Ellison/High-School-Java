
public class Circle extends Round{

	private int radius;
	private double area;
	private double perimeter;
	
	public Circle(int x,int y,int r) {
		super(x,y,(Math.PI*r*r),(2*Math.PI*r));
		radius = r;
		findArea();
		findPerimeter();
		super.changePerimeter(perimeter);
	}

	private void findPerimeter() {
		perimeter = (2*Math.PI*radius);
	}

	private void findArea() {
		 area = (Math.PI*radius*radius);
	}
	
	public int getRadius() {
		return radius;
	}
	
	/**public void printFacts() {
		System.out.println("Circle:");
		super.printFacts();
		System.out.println("The radius is: " + radius);
		System.out.println();
	}**/
}
