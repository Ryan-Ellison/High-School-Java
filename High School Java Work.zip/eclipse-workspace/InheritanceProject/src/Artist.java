import java.util.ArrayList;

public class Artist {
	public static void main (String[] args) {
		/**ArrayList<Shape> Shapes=new ArrayList<Shape>();
		Shape shapy = new Shape(12,7);
		FlatSided flatty = new FlatSided(9,10,11,12,50.0);
		Trapezoid trappy = new Trapezoid(1,3,2,5,3);
		Circle circy = new Circle(0,0,3);
		Ellipse ellipsy = new Ellipse(0,0,2,4);
		Shapes.add(shapy);
		Shapes.add(flatty);
		Shapes.add(trappy);
		Shapes.add(circy);
		Shapes.add(ellipsy);
		for(Shape number:Shapes) {
			number.printFacts();
			System.out.println();
		}**/
		//Shape hape=new Shape(2,7);
		//FlatSided anvil = new FlatSided(1,2,3,4,5.0);
		Rectangle r=new Rectangle(5,3,5,3);
		r.printFacts();
		
	}

	public static void trapOutputs(Trapezoid shape) {
		System.out.println("Trapezoid:");
		System.out.println("The height of this trapezoid is: " + shape.getHeight());
		System.out.println("The area is: " + shape.getArea());
		System.out.println("The perimeter is: " + shape.getPerimeter());
		System.out.println("The the lengths are: " + shape.getLengths());
		System.out.println();
	}
	
	public static void rectOutputs(Rectangle shape) {
		System.out.println("Rectangle:");
		System.out.println("Is this shape a square? " + shape.getSquare());
		System.out.println("The area is: " + shape.getArea());
		System.out.println("The perimeter is: " + shape.getPerimeter());
		System.out.println("The the lengths are: " + shape.getLengths());
		System.out.println();
	}
	
	public static void circleOutputs(Circle shape) {
		System.out.println("Circle:");
		System.out.println("The center X point is: " + shape.getX());
		System.out.println("The center Y point is: " + shape.getY());
		System.out.println("The radius is: " + shape.getRadius());
		System.out.println("The area is: " + shape.getArea());
		System.out.println("The perimeter is: " + shape.getPerimeter());
		System.out.println();
	}
	
	public static void ellipseOutputs(Ellipse shape) {
		System.out.println("Ellipse:");
		System.out.println("The center X point is: " + shape.getX());
		System.out.println("The center Y point is: " + shape.getY());
		System.out.println("The first length is: " + shape.getA());
		System.out.println("The second length is: " + shape.getB());
		System.out.println("The area is: " + shape.getArea());
		System.out.println("The perimeter is: " + shape.getPerimeter());
		System.out.println();
	}
}
