
public class Trapezoid extends FlatSided{
	
	double height;
	double area;
	
	public Trapezoid(int a,int b,int c,int d, int h) {
		super(a,b,c,d,-5.0);
		findArea(a,b,c,d,h);
		height=h;
		super.changeArea(area);
	}

	private void findArea(int a, int b, int c, int d, int h) {
		double temp=0;
		if(temp<a)
			temp=a;
		if(temp<b)
			temp=b;
		if(temp<c)
			temp=c;
		if(temp<d)
			temp=d;
		if(a==temp||c==temp)
			area = ((a+c)/2.0*h);
		else
			area = ((b+d)/2.0*h);
			
	}
	
	public double getHeight() {
		return height;
	}
	
	public void printFacts() {
		System.out.println("Trapezoid:");
		super.printFacts();
		System.out.println("The height of this trapezoid is: " + height);
		System.out.println();
	}
}
