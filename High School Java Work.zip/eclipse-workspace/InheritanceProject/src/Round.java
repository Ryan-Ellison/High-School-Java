
public class Round extends Shape{
	
	private int centerX;
	private int centerY;
	private double area;
	private double perimeter;
	
	public Round(int x, int y, double a, double p) {
		super(a);
		centerX=x;
		centerY=y;
		area=a;
		perimeter=p;
	}
	
	public int getX() {
		return centerX;
	}
	
	public int getY() {
		return centerY;
	}
	
	public void printFacts() {
		super.printFacts();
		System.out.println("The center X point is: " + centerX);
		System.out.println("The center Y point is: " + centerY);
	}
}
