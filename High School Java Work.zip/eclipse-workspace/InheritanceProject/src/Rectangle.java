
public class Rectangle extends FlatSided{
	
	boolean square;
	
	public Rectangle(int a, int b, int c, int d) {
		super(a, b, c, d, a*b);
		isSquare(a,b,c,d);
		super.changeArea(a*b);
		super.changePerimeter(a+b+c+d);
	}
	
	@SuppressWarnings("unused")
	private static double findArea(int a, int b, int c, int d) {
		
		if(a!=b)
			return (a*b);
		else if(a!=c)
			return(a*c);
		else
			return(a*d);
	}

	private void isSquare(int a, int b, int c, int d) {
		if(a==b&&a==c&&a==d)
			square=true;
		else
			square=false;
	}
	
	public boolean getSquare() {
		return square;
	}
	
	public void printFacts() {
		System.out.println("Rectangle:");
		super.printFacts();
		System.out.println("Is this shape a square? " + square);
		System.out.println();
	}

	
}
