
public class Ellipse extends Round{
	
	private int centerX;
	private int centerY;
	private int a;
	private int b;
	private double area;
	private double perimeter;
	
	public Ellipse(int x, int y, int ay, int bee) {
		super(x,y,Math.PI*ay*bee,-25.0);
		centerX=x;
		centerY=y;
		a=ay;
		b=bee;
		area=Math.PI*a*b;
		perimeter=(2.0*Math.PI*Math.sqrt(((double)(a*a)+(double)(b*b))/2.0));
		super.changePerimeter(perimeter);
		}
	
	public int getA() {
		return a;
	}
	
	public int getB() {
		return b;
	}
	
	public void printFacts() {
		System.out.println("Ellipse:");
		super.printFacts();
		System.out.println("The a is: " + a);
		System.out.println("The b is: " + b);	
		System.out.println();
	}
	
	
	}
