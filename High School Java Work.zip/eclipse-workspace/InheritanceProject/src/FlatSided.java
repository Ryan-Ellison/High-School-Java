import java.util.ArrayList;

public class FlatSided extends Shape{
	
	private ArrayList<Integer> lengths=new ArrayList<Integer>();
	
	public FlatSided(int a, int b, int c, int d,double area) {
		super(area, a+b+c+d);
		lengths.add(a);
		lengths.add(b);
		lengths.add(c);
		lengths.add(d);
	}
	
	public FlatSided(int a, int b, int c, int d) {
		super();
		lengths.add(a);
		lengths.add(b);
		lengths.add(c);
		lengths.add(d);
		setPerimeter(this.findPerimeter());
	}
	
	public ArrayList<Integer> getLengths() {
		return lengths;
	}
	
	public void printFacts() {
		super.printFacts();
		System.out.println("The lengths are: " + lengths);
	}
	
	public double findPerimeter() {
		double sum=0;
		for(double side:lengths) {
			sum+=side;
		}
		return sum;
	}

	@Override
	public double findArea() {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
