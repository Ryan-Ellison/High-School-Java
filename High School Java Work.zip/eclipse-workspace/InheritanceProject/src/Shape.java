
public abstract class Shape {
	private double area;
	private double perimeter;
	
	public Shape() {
		area=99;
		perimeter=-34;
	}
	
	public Shape(double a) {
		area=a;
		perimeter=-99;
	}
	
	public Shape(double a, double p) {
		area=a;
		perimeter=p;
	}
	
	public void changeArea(double a) {
		area=a;
	}
	
	public void changePerimeter(double p) {
		perimeter=p;
	}
	
	public double getArea() {
		return area;
	}
	
	public double getPerimeter() {
		return perimeter;
	}
	
	public void printFacts() {
		System.out.println("The area is: " + area);
		System.out.println("The perimeter is: " + perimeter);
	}
	
	public void setPerimeter(double p) {
		this.perimeter=p;
	}
	
	public abstract double findArea();
	
	public abstract double findPerimeter();

}
