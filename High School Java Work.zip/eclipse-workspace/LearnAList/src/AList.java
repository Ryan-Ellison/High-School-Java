import java.util.ArrayList;
public class AList {

	public static void main(String[] args) {
		ArrayList<String> names=new ArrayList<String>();
		names.add("Anna");
		names.add("Josey");
		names.add("Ana");
		names.add("Jordan");
		names.add("Anna");
		boolean duplicates=hasDuplicates(names);
		while(hasDuplicates(names)) {
			removeDuplicate(names);
		}
		sortList(names);
		System.out.println(names);
		/**
		 * ArrayList<Integer> numNumz=new ArrayList<Integer>;
		 * nunNumz.add(3);
		 * nunNumz.add(0);
		 * nunNumz.add(5);
		 * int sums=nunNumz.get(0)+numNumz.get(2)
		 */
	}

	public static boolean hasDuplicates(ArrayList<String> names) {
		for(int i=0;i<names.size()-1;i++) {
			for(int j=i+1;j<names.size();j++) {
				if(names.get(i).equals(names.get(j))) {
					return true;
				}
			}
		}
		return false;
	}
	
	public static void removeDuplicate(ArrayList<String> names) {
		for(int i=0;i<names.size()-1;i++) {
			for(int j=i+1;j<names.size();j++) {
				if(names.get(i).equals(names.get(j))) {
					names.remove(j);
				}
			}
		}
	}
	
	public static void sortList(ArrayList<String> names) {
		for(int i=0;i<names.size()-1;i++) {
			for(int j=i+1;j<names.size();j++) {
				if(names.get(i).compareTo(names.get(j))>0) {
					names.add(i,names.remove(j));
					j=names.size();
					i=0;
				}
			}
		}
	}
}
