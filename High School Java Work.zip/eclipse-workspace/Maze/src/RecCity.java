
public class RecCity {

	private static int sI=0; //startingRow
	private static int sJ=0; //startingColumns
	private static int boardSZ=10; //board size(square);
	private static int fI=boardSZ-1; //finalRow
	private static int fJ=boardSZ-1; //finalColumn
	private static boolean[][] board = new boolean[boardSZ][boardSZ];
	private static boolean win = false;
	
	public static void main(String[] args) {
		
		//initialize board
		for(int i=0;i<boardSZ;i++) {
			for(int j=0;j<boardSZ;j++) {
				board[i][j]=true;
			}
		}
		
		//put in obstacles
		addObstacles(5);

		for(int i=0;i<boardSZ;i++) {
			for(int j=0;j<boardSZ;j++) {
				if(!board[i][j])
					System.out.println("T");
			}
		}
		
		move(sI,sJ);
		if(win) {
			System.out.println("The champ is here");
			System.out.println("~Muhammad Ali");
		}
		else {
			System.out.println("The champ is not here");
		}
		
	}//end main
	
	private static void addObstacles(int x) {
		int a;
		int b;
		int i=0;
		while(i<x) {
			a=(int)(Math.random()*boardSZ);
			b=(int)(Math.random()*boardSZ);
			if(((a!=sI)||(b!=sJ))&&((a!=fI)||(b!=fJ))
					&&(board[a][b])) {
				System.out.println("a = " + a + " b = " + b);
				board[a][b]=false;
				i++;
			}
		}
	}
	
	private static void move(int i, int j) {
		System.out.println("I'm at (" + i + "," + j + ")");
		if((i==fI)&&(j==fJ)) {
			System.out.println("The champ is here");
			System.out.println("~Muhammad Ali");
			win=true;
			return;
		}
		if(((i>=boardSZ)||(j>=boardSZ))||(!board[i][j])) {
			return;
		}
		move(i,j+1);
		move(i+1,j);
		move(i+1,j+1);
	}
}

