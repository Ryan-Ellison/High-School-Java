
public class Square {

	public static void main(String[] args) {
		int n=6;
		int[][] square=new int[n][n];
		fillArray(square);
		square[0][5]=100;
		int largestElement=largestElement(square);
		int largestRow=largestRow(square);
		int largestColumn=largestColumn(square);
		int largestDiagonal=largestDiagonal(square);
		outputs(square,largestElement,largestRow,largestColumn,largestDiagonal);
	}
	
	public static void fillArray(int[][] array) {
		for(int i=0;i<array.length;i++) {
			for(int j=0;j<array[0].length;j++) {
				array[i][j]=(int)(Math.random()*10)+1;
			}
		}
	}
	
	public static int largestElement(int[][] array) {
		int temp=0;
		for(int i=0;i<array.length;i++) {
			for(int j=0;j<array[0].length;j++) {
				if(array[i][j]>temp)
					temp=array[i][j];
			}
		}
		return temp;
	}
	
	public static int largestRow(int[][] array) {
		int rowNumber=0;
		int temp1=0;
		int temp2=0;
		for(int i=0;i<array.length;i++) {
			temp2=0;
			for(int j=0;j<array[0].length;j++) {
				temp2+=array[i][j];
			}
			if(temp2>temp1) {
				temp1=temp2;
				rowNumber=i;
			}
		}
		return rowNumber;
	}
	
	public static int largestColumn(int[][] array) {
		int columnNumber=0;
		int temp1=0;
		int temp2=0;
		for(int i=0;i<array[0].length;i++) {
			temp2=0;
			for(int j=0;j<array.length;j++) {
				temp2+=array[j][i];
			}
			if (temp2>temp1) {
				temp1=temp2;
				columnNumber=i;
			}
		}
		return columnNumber;
	}
	
	public static int largestDiagonal(int[][] array) {
		int temp1=0;
		int temp2=0;
		for(int i=0;i<array.length;i++) {
			temp1+=array[i][i];
		}
		for(int i=0;i<array.length;i++) {
			temp2+=array[array.length-i-1][i];
		}
		if(temp1>=temp2) 
			return -1;
		else 
			return 1;
	}
	
	public static void outputs(int[][] array, int element, int row, int column, int diagonal) {
		for(int i=0;i<array.length;i++) {
			for(int j=0;j<array[0].length;j++) {
				System.out.print(array[i][j] + " ");
			}
			System.out.println();
		}
		System.out.println("The largest element is " + element);
		System.out.println("The largest row is " + row);
		System.out.println("The largest column is " + column);
		System.out.println("The largest diagonal is " + diagonal);
	}
}
